# zepto-lily-be

# Run In Local

## `yarn install`

## `yarn run start`

# Run In Prod

## `yarn install --production`

## `yarn run build`

## `yarn run --production start`