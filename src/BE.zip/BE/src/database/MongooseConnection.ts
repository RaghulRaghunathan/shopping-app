import mongoose from "mongoose";
import { secretReader } from "../services/aws/secrets_manager/secrets";
import logger from "../helpers/logger";

export class MongooseConnection {
  private static instance: MongooseConnection;
  public secretValues: any = {};

  public connect(): any {
    this.secretValues = secretReader.secretValues;
    this.init();
  }

  public static getInstance(): MongooseConnection {
    if (!MongooseConnection.instance) MongooseConnection.instance = new MongooseConnection();
    return MongooseConnection.instance;
  }

  private async init(): Promise<void> {
    try {
      const options = {
        autoIndex: true,
        maxPoolSize: 10, // Maintain up to 10 socket connections
        socketTimeoutMS: 45000, // Close sockets after 45 seconds of inactivity
        connectTimeoutMS: 10000, // Give up initial connection after 10 seconds
        tls: true,
        tlsAllowInvalidCertificates: true,
      };

      const dbURI = `mongodb://${this.secretValues?.db_username}:${this.secretValues?.db_password}@${this.secretValues?.db_uri}/${this.secretValues?.db_name}?ssl=true&retryWrites=false`;

      // Create the database connection
      mongoose
        .connect(dbURI, options)
        .then(() => {
          logger.info("[Mongoose]: Connection done");
        })
        .catch((err: any) => {
          logger.info("[Mongoose]: Connection error");
          logger.error(err);
        });

      // CONNECTION EVENTS
      // When successfully connected
      mongoose.connection.on("connected", () => {
        logger.info(
          `[Mongoose]: Default connection open to ${this.secretValues?.db_uri}/${this.secretValues?.db_name}`
        );
      });

      // If the connection throws an error
      mongoose.connection.on("error", (err) => {
        logger.error("[Mongoose]: Default connection error");
        logger.error(err);
      });

      // When the connection is disconnected
      mongoose.connection.on("disconnected", () => {
        logger.info("[Mongoose]: Default connection disconnected");
      });

      // If the Node process ends, close the [Mongoose] : connection
      process.on("SIGINT", () => {
        mongoose.connection.close(() => {
          logger.info("[Mongoose]: Default connection disconnected through app termination");
          process.exit(0);
        });
      });
    } catch (ex) {
      logger.error("[Mongoose]: Error occurred at DB connection: exiting app ".concat(ex));
      process.exit(1);
    }
  }
}

export const mongooseConnection = MongooseConnection.getInstance();
