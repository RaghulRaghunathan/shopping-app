import { Schema, model } from "mongoose";
import { secretReader } from "../../services/aws/secrets_manager/secrets";
import { IRetailer, SkillsEnum } from "../types";

const retailerSchema = new Schema<IRetailer>(
  {
    clientId: { type: String, required: true },
    id: { type: String, required: true },
    name: { type: String, required: true },
    teams: { type: [String], required: true },
    skills: { type: [String], required: true, enum: SkillsEnum },
    address: {
      id: { type: String, required: false },
      placeName: { type: String, required: false },
      localityName: { type: String, required: false },
      formattedAddress: { type: String, required: true },
      subLocalityName: { type: String, required: false },
      pincode: { type: String, required: false },
      city: { type: String, required: false },
      state: { type: String, required: false },
      countryCode: { type: String, required: false, default: "EG" },
      locationType: { type: String, required: false },
      placeHash: { type: String, required: false },
    },
    location: {
      type: {
        type: String,
        required: true,
        enum: ["Point"],
        default: "Point",
      },
      coordinates: { type: [Number, Number], required: true },
    },
    capacity: Number,
    date: { type: String, required: true },
    updatedAt: Date,
    createdAt: {
      type: Date,
      default: Date.now,
      expires: "2d",
    },
  },
  { timestamps: true }
);

retailerSchema.pre("validate", function (next) {
  if (!this.clientId) {
    const secretValues = secretReader.get();
    this.clientId = secretValues?.client_id;
  }
  next();
});

retailerSchema.index({ id: 1, clientId: 1, date: 1 }, { unique: true });
retailerSchema.index({ location: "2dsphere" });

const Retailer = model<IRetailer>("Retailer", retailerSchema);

export default Retailer;
export { IRetailer };
