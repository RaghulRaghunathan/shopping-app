import Retailer, { IRetailer } from "../model/RetailStoreEntity";

export const insertBulkRetailerDetails = (data: IRetailer[]) => {
  return Retailer.insertMany(data, { ordered: false });
};

export const getRetailerCount = (clientId: string, date: string) => {
  return Retailer.count({ clientId: { $eq: clientId }, date: { $eq: date } });
};

export const getNearestRetailer = (
  clientId: string,
  skill: string,
  team: string,
  capacity: number,
  date: string,
  lat: Number,
  lng: Number
) => {
  return Retailer.findOneAndUpdate(
    {
      clientId: { $eq: clientId },
      skills: { $in: [skill] },
      teams: { $in: [team] },
      capacity: { $gte: capacity },
      date: { $eq: date },
      location: {
        $nearSphere: {
          $geometry: { type: "Point", coordinates: [lat, lng] },
          $maxDistance: 3000,
        },
      },
    },
    { $inc: { capacity: -1 * capacity } }
  )
    .lean()
    .exec();
};

export const retainRetailerCapacity = (query: any[]) => {
  return Retailer.bulkWrite(query, { ordered: false });
};

export const updatedRetailerCapacity = (retailerId: any, capacity: number) => {
  return Retailer.findOneAndUpdate(
    {
      _id: { $eq: retailerId },
    },
    { $inc: { capacity: -1 * capacity } }
  )
    .lean()
    .exec();
};

export const deleteRetailer = (query: any) => {
  return Retailer.deleteMany(query);
};
