import { Types, Document } from "mongoose";

export enum SkillsEnum {
  SMALL,
  MEDIUM,
  LARGE,
}

interface IAddress extends Document {
  id?: string;
  placeName?: string;
  localityName?: string;
  formattedAddress: string;
  subLocalityName?: string;
  pincode?: string;
  city?: string;
  state?: string;
  countryCode?: string;
  locationType?: string;
  placeHash?: string;
}

interface ILocation extends Document {
  type: string;
  coordinates: Array<Number>[2];
}

export interface IRetailer extends Document {
  _id: Types.ObjectId;
  clientId: string;
  id: string;
  name: string;
  teams: string[];
  skills: SkillsEnum[];
  address: IAddress;
  location: ILocation;
  capacity: Number;
  date: string;
  createdAt: Date;
  updatedAt: Date;
}
