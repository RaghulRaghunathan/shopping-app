import { Request } from 'express';
import { take, ApiResult, exception } from '../../lib/express';
import logger from '../../helpers/logger';
import { awsS3 } from '../../services/aws/s3';
import { messages } from '../../constants/messages';

export class Callback {
    public async updateTour(req: Request): Promise<ApiResult> {
        try {
            const payload: any = req.body;
            const buffer = Buffer.from(JSON.stringify(payload));
            const tourId = payload?.tourDetail?.tourId;

            if (!tourId)
                throw take(messages['1003'].messageCode, null, { message: 'Tour ID not found' });

            const uploadRes = await awsS3.uploadObject(
                buffer,
                'application/json',
                `tour/${tourId}.json`,
            );
            if (uploadRes.status) return take(messages['2000'].messageCode);
            throw take(messages['1003'].messageCode, uploadRes);
        } catch (ex) {
            logger.error(`[API] [${req.originalUrl}] Response: ${JSON.stringify(ex)}`);
            return exception(ex);
        }
    }

    public async updateOrderStatus(req: Request): Promise<ApiResult> {
        try {
            const payload: any = req.body;
            const buffer = Buffer.from(JSON.stringify(payload));
            const orderId = payload?.order?.id;

            if (!orderId)
                throw take(messages['1003'].messageCode, null, { message: 'Order ID not found' });

            const uploadRes = await awsS3.uploadObject(
                buffer,
                'application/json',
                `status/${orderId}.json`,
            );
            if (uploadRes.status) return take(messages['2000'].messageCode);
            throw take(messages['1003'].messageCode, uploadRes);
        } catch (ex) {
            logger.error(`[API] [${req.originalUrl}] Response: ${JSON.stringify(ex)}`);
            return exception(ex);
        }
    }
}
