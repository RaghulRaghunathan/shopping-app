import { Request } from 'express';
import { take, ApiResult, exception } from '../../lib/express';
import logger from '../../helpers/logger';
import { messages } from '../../constants/messages';

export class Health {
    public async getHealth(req: Request): Promise<ApiResult> {
        try {
            return take(messages['1101'].messageCode);
        } catch (ex) {
            logger.error(`[API] [${req.originalUrl}] Response: ${JSON.stringify(ex)}`);
            return exception(ex);
        }
    }

    public async checkHealthCode(req: Request): Promise<ApiResult> {
        try {
            return take(messages['1102'].messageCode);
        } catch (ex) {
            logger.error(`[API] [${req.originalUrl}] Response: ${JSON.stringify(ex)}`);
            return exception(ex);
        }
    }
}
