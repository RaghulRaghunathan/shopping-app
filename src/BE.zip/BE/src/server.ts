import http from 'http';
import express from 'express';
import { App } from './app';
import { configReader, AppConfig } from './config';
import logger from './helpers/logger';

class Server {
    private app: express.Express;
    private server: http.Server;
    private port: any;
    private appConfig: AppConfig;

    constructor() {
        this.onListening = this.onListening.bind(this);
        this.onError = this.onError.bind(this);
        this.appConfig = configReader.get();
    }

    public run(): void {
        this.app = new App().app;
        this.port = this.appConfig.app.port;
        this.app.set('port', this.port);

        this.server = http.createServer(this.app);
        this.server.listen(this.port);
        this.server.on('error', this.onError);
        this.server.on('listening', this.onListening);

        const unexpectedErrorHandler = (error: any) => {
            logger.error(`[SERVER] Unexpected error: ${error}`);
            this.server.close(() => {
                logger.info('[SERVER] app closed');
                process.exit(1);
            });
        };

        process.on('uncaughtException', unexpectedErrorHandler);
        process.on('unhandledRejection', unexpectedErrorHandler);

        process.on('SIGTERM', () => {
            this.server.close(() => {
                logger.info('[SERVER] app gracefully terminated using SIGTERM');
            });
        });
    }

    private onError(error: any): void {
        if (error.syscall !== 'listen') throw error;

        const bind = typeof this.port === 'string' ? 'Pipe ' + this.port : 'Port ' + this.port;
        // handle specific listen errors with friendly messages
        if (error.code === 'EADDRINUSE') {
            logger.error(`[SERVER] ${bind} is already in use`);
            process.exit(1);
        } else throw error;
    }

    private onListening(): void {
        const addr = this.server.address();
        const bind = typeof addr === 'string' ? 'pipe ' + addr : 'port ' + addr.port;
        logger.info(`[SERVER] Listening on ${bind}`);
    }
}

// Run HTTP server
new Server().run();
