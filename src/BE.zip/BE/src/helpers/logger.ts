import winston from 'winston';
const newrelicFormatter = require("@newrelic/winston-enricher")(winston);

const enumerateErrorFormat = winston.format((info) => {
    if (info instanceof Error) {
        Object.assign(info, { message: info.stack });
    }
    return info;
});

const logger = winston.createLogger({
    level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
    format: winston.format.combine(
        enumerateErrorFormat(),
        process.env.NODE_ENV === 'production'
            ? winston.format.uncolorize()
            : winston.format.colorize(),
        winston.format.splat(),
        winston.format.printf(({ level, message }) => `${level}: ${message}`),
        newrelicFormatter()
    ),
    transports: [
        new winston.transports.Console({
            stderrLevels: ['error'],
        }),
    ],
});

export default logger;
