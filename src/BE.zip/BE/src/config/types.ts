export interface AppConfig {
    app: {
        version: string;
        name: string;
        port: number;
        timezone: string;
        environment: string;
        baseUrl: string;
        corsUrl: any;
    };
    aws: {
        secretName: string;
    };
}
