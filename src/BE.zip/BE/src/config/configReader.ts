import { AppConfig } from './types';
import appPackage from '../../package.json';
import dotenv from 'dotenv';
import defaultConfig from './default.json';
import logger from '../helpers/logger';
export class ConfigReader {
    private static instance: ConfigReader;
    public config: AppConfig;

    constructor() {
        // load env configurations
        dotenv.config();
        this.envConfLoad();
    }

    public static getInstance(): ConfigReader {
        if (!ConfigReader.instance) ConfigReader.instance = new ConfigReader();
        return ConfigReader.instance;
    }

    public get(): AppConfig {
        return this.config;
    }

    private envConfLoad(): void {
        try {
            this.config = JSON.parse(JSON.stringify(defaultConfig.config));
            this.config.app.port = Number(process.env.PORT) || this.config.app.port || 3000;
            this.config.app.environment = process.env.NODE_ENV;
            this.config.aws.secretName = process.env.AWS_SECRET_NAME;
            this.config.app.name = appPackage.name;
        } catch (ex) {
            logger.error(`[CONFIG] Reading config - ${ex.message}`);
            throw ex;
        }
    }
}

export const configReader = ConfigReader.getInstance();
