import logger from '../helpers/logger';
import { Middleware, RequestX, ResponseX, NextFunctionX, take } from '../lib/express';

export class AuthMiddleware implements Middleware {
    public use(req: RequestX, res: ResponseX, next: NextFunctionX): void {
        next();
    }
}
