import { Middleware, RequestX, ResponseX, NextFunctionX, take } from '../lib/express';
import { validationResult } from 'express-validator';
import logger from '../helpers/logger';
import { messages } from '../constants/messages';
const validator = require('express-validator');

export class ValidatorMiddleware implements Middleware {
    public use(req: RequestX, res: ResponseX, next: NextFunctionX): void {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            logger.error(
                `[API] [${req.originalUrl}] Response: Validation error, ${JSON.stringify(
                    errors.array(),
                )}`,
            );
            res.validationError(
                take(messages['1001'].messageCode, {
                    errors: errors.array({ onlyFirstError: true }).map((item) => {
                        if (item.location === 'body') return item;
                        else return item.msg;
                    }),
                }),
            );
        } else next();
    }
}

export const expressValidator = () => {
    return validator();
};
