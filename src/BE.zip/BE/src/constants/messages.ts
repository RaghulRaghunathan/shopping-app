import { HttpStatus } from '../lib/express';

export const messages = {
    // COMMON
    1001: {
        message: 'Validation Errors',
        messageCode: 1001,
        httpStatus: HttpStatus.UNPROCESSABLE_ENTITY,
    },
    1002: {
        message: 'Unexpected error',
        messageCode: 1002,
        httpStatus: HttpStatus.INTERNAL_SERVER_ERROR,
    },
    1003: {
        message: 'Something went wrong',
        messageCode: 1003,
        httpStatus: HttpStatus.INTERNAL_SERVER_ERROR,
    },

    //Health
    1101: {
        message: 'Healthy',
        messageCode: 1101,
        httpStatus: HttpStatus.OK,
    },
    1102: {
        message: 'Healthy Code',
        messageCode: 1102,
        httpStatus: HttpStatus.OK,
    },

    2000: {
        message: 'Success',
        messageCode: 2000,
        httpStatus: HttpStatus.OK,
    },

    //Auth
    3001: {
        message: 'Authentication failure',
        messageCode: 3001,
        httpStatus: HttpStatus.UNAUTHORIZED,
    },
};
