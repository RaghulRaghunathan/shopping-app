import express, { Request, Response, NextFunction } from 'express';
import compression from 'compression';
import helmet from 'helmet';
import morgan from 'morgan';
import cors from 'cors';
import {
    apiMiddleware,
    RequestX,
    ResponseX,
    NextFunctionX,
    metaDataMiddleware,
} from './lib/express';
import { configReader, AppConfig } from './config';
import { messages } from './constants/messages';
import { combineApiRoutes } from './apiRoutes';
import logger from './helpers/logger';
import moment from 'moment-timezone';
import { secretReader } from './services/aws/secrets';

export class App {
    public app: express.Express;
    private appConfig: AppConfig;

    constructor() {
        this.appConfig = configReader.get();
        this.app = express();

        moment.defaultFormat = 'YYYY-MM-DDTHH:mm:ss.SSSZ';

        this.middlewareHandler();
        this.routesHandler();
        this.errorHandler();
        this.initDependencies();
    }

    private async initDependencies(): Promise<void> {
        await secretReader.init();
    }

    private middlewareHandler(): void {
        // configure additional things to request & response.
        // configure messages
        this.app.use(apiMiddleware({ version: this.appConfig.app.version, messages }));

        const corsOptions = {
            origin: this.appConfig.app.corsUrl,
            methods: ['GET', 'PUT', 'POST'],
            allowedHeaders: ['Content-type', 'Accept'],
        };
        this.app.all('/*', cors(corsOptions));

        this.app.use(express.json({ limit: '50mb' }));
        this.app.use(express.urlencoded({ limit: '50mb', extended: true }));
        this.app.use(express.static('public'));
        this.app.use(compression());
        this.app.use(helmet());

        morgan.token('params', (req: Request) => JSON.stringify(req.params));
        morgan.token('query', (req: Request) => JSON.stringify(req.query));
        const MORGAN_LOG_FORMAT =
            ':remote-addr :remote-user :method :url HTTP/:http-version :status :res[content-length] - :response-time ms :params :query';

        this.app.use(
            morgan(MORGAN_LOG_FORMAT, {
                skip: (req: Request) => req.originalUrl === '/health',
                stream: {
                    write: (meta: string) => {
                        const metadata = meta.split(' ');
                        logger.info(`[API] [${metadata[3]}] : Response details - ${meta}`);
                    },
                },
            }),
        );
    }

    private routesHandler(): void {
        // this.app.use(expressValidator());
        this.app.use(metaDataMiddleware);
        this.app.set('port', this.appConfig.app.port);

        this.app.use((req: Request, res: Response, next: NextFunction) => {
            if (req.url === '/')
                return res.json({
                    version: this.appConfig.app.version,
                    name: this.appConfig.app.name,
                    env: this.appConfig.app.environment,
                });
            else next();
        });

        combineApiRoutes(this.app);
    }

    private errorHandler(): void {
        this.app.use((err: Error, _req: RequestX, res: ResponseX, _next: NextFunctionX) => {
            logger.error(`[SERVER] Server error, ${err}`);
            res.serverError(err);
        });

        // catch 404 and forward to error handler
        this.app.use((_req: RequestX, res: ResponseX) => {
            logger.error(`[API] API not found, ${_req.originalUrl}`);
            res.apiNotFound();
        });
    }
}
