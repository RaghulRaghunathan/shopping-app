import { getMeta } from './meta';

export const Authenticate = () => {
    return (target: any, key: string, descriptor: PropertyDescriptor) => {
        const meta = getMeta(target);
        meta.auth[key] = {};
        return descriptor;
    };
};
