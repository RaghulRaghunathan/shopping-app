import { getMeta } from './meta';
import { Type } from './middleware';

export const decoratorFactory = (method: string, url: string, middleware?: Type[]) => {
    return (target: any, key: string, descriptor: PropertyDescriptor) => {
        const meta = getMeta(target);
        meta.routes[key] = { method, url, middleware };
        return descriptor;
    };
};

export const ALL = (url: string, middleware?: Type[]) => {
    return decoratorFactory('all', url, middleware);
};

export const GET = (url: string, middleware?: Type[]) => {
    return decoratorFactory('get', url, middleware);
};

export const POST = (url: string, middleware?: Type[]) => {
    return decoratorFactory('post', url, middleware);
};

export const PUT = (url: string, middleware?: Type[]) => {
    return decoratorFactory('put', url, middleware);
};

export const DELETE = (url: string, middleware?: Type[]) => {
    return decoratorFactory('delete', url, middleware);
};

export const PATCH = (url: string, middleware?: Type[]) => {
    return decoratorFactory('patch', url, middleware);
};

export const OPTIONS = (url: string, middleware?: Type[]) => {
    return decoratorFactory('options', url, middleware);
};

export const HEAD = (url: string, middleware?: Type[]) => {
    return decoratorFactory('head', url, middleware);
};
