import { getMeta } from './meta';
import { Type } from './middleware';

export const ApiRoutes = (url: string, middleware?: Type[]) => {
    return (target: any) => {
        const meta = getMeta(target.prototype);
        meta.url = url;
        meta.middleware = middleware;
    };
};
