import { getMeta, ExpressMeta, Rule } from './meta';

export const Validate = (rules: Rule[]) => {
    return (target: any, key: string, descriptor: PropertyDescriptor) => {
        const meta: ExpressMeta = getMeta(target);
        meta.validations[key] = { rules };
        return descriptor;
    };
};
