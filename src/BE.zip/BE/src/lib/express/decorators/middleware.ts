import { Container, InjectionToken } from '@decorators/di';
import { Request, Response, NextFunction, ErrorRequestHandler } from 'express';

export interface Middleware {
    use(request: Request, response: Response, next: NextFunction, params?: any): void;
}

export interface Type extends Function {
    new (...args: any[]): any;
}

export const middlewareHandler = (middleware: Type, params?: any) => {
    return (req: Request, res: Response, next: NextFunction) => {
        try {
            if (params) return getMiddleware(middleware, [req, res, next, params]);
            return getMiddleware(middleware, [req, res, next]);
        } catch (error) {
            next(error);
        }
    };
};

export const ERROR_MIDDLEWARE = new InjectionToken('ERROR_MIDDLEWARE');

export const errorMiddlewareHandler = () => {
    return function (error: ErrorRequestHandler, req: Request, res: Response, next: NextFunction) {
        try {
            return getMiddleware(exports.ERROR_MIDDLEWARE, [error, req, res, next]);
        } catch (_a) {
            next(error);
        }
    };
};

function getMiddleware(middleware: Type, args: any[]) {
    const next = args[args.length - 1]; // last parameter is always the next function
    let instance;
    try {
        // first, trying to get instance from the container
        instance = Container.get(middleware);
    } catch (_a) {
        try {
            // if container fails, trying to instantiate it
            instance = new middleware();
        } catch (_b) {
            // if instantiation fails, try to use it as is
            instance = middleware;
        }
    }
    // first, assuming that middleware is a class, try to use it,
    // otherwise use it as a function
    const result = instance.use
        ? instance.use.apply(instance, args)
        : instance.apply(instance, args);
    // if result of execution is a promise, add additional listener to catch error
    if (result instanceof Promise) {
        result.catch((e) => next(e));
    }
    return result;
}
