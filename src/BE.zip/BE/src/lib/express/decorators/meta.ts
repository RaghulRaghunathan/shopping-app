import { Type } from './middleware';

export declare enum ParameterType {
    REQUEST = 0,
    RESPONSE = 1,
    PARAMS = 2,
    QUERY = 3,
    BODY = 4,
    HEADERS = 5,
    COOKIES = 6,
    NEXT = 7,
}

export interface ParameterConfiguration {
    index: number;
    type: ParameterType;
    name?: string;
    data?: any;
}

export interface Route {
    method: string;
    url: string;
    middleware: Type[];
}

export interface Auth {}

export interface Rule extends Function {}

export interface Validations {
    rules: Rule[];
}

export interface ExpressMeta {
    url: string;
    routes: {
        [key: string]: Route;
    };
    middleware: Type[];
    params: {
        [key: string]: ParameterConfiguration[];
    };
    validations: {
        [key: string]: Validations;
    };
    auth: {
        [key: string]: Auth;
    };
}

export interface ExpressClass {
    __express_meta__?: ExpressMeta;
}

export const getMeta = (target: ExpressClass): ExpressMeta => {
    if (!target.__express_meta__) {
        target.__express_meta__ = {
            url: '',
            middleware: [],
            routes: {},
            auth: {},
            validations: {},
            params: {},
        };
    }
    return target.__express_meta__;
};
