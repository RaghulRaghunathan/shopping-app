import { Express, Router, NextFunction } from 'express';
import { Type, middlewareHandler, errorMiddlewareHandler } from './middleware';
import { ExpressClass, getMeta } from './meta';
import { Container } from '@decorators/di';
import { RequestX, ResponseX } from '../types/express';

interface ApiRouteOptions {
    middleware?: {
        auth?: Type;
        validator?: Type;
    };
}

export const attachApiRoutes = (
    app: Express | Router,
    apiRoutes: Type[],
    options?: ApiRouteOptions,
) => {
    apiRoutes.forEach((apiRoute) => registerApiRoute(app, apiRoute, options));
    // error middleware must be registered as the very last one
    app.use(errorMiddlewareHandler());
};

function registerApiRoute(app: Express | Router, ApiRoute: any, options?: ApiRouteOptions) {
    const router: any = Router({ mergeParams: true });

    const apiRoute: any = getApiRoute(ApiRoute);
    const meta = getMeta(apiRoute);

    const routes = meta.routes;
    const url = meta.url;
    const auth = meta.auth;
    const validations = meta.validations;
    const routerMiddleware = (meta.middleware || []).map((middleware) =>
        middlewareHandler(middleware),
    );

    if (routerMiddleware.length) {
        router.use(...routerMiddleware);
    }

    for (const methodName of Object.keys(routes)) {
        const route = routes[methodName];
        const routeHandler = (req: RequestX, res: ResponseX, next: NextFunction) => {
            const args = [req, res, next];
            const handler = apiRoute[methodName].apply(apiRoute, args);
            if (handler instanceof Promise) {
                handler.then(res.ok).catch(res.error);
            }
            return handler;
        };

        const routeMiddleware = [];
        if (options?.middleware?.auth && auth.hasOwnProperty(methodName))
            routeMiddleware.push(middlewareHandler(options.middleware.auth));
        if (route?.middleware?.length)
            route.middleware.forEach((middleware) =>
                routeMiddleware.push(middlewareHandler(middleware)),
            );
        if (options?.middleware?.validator && validations.hasOwnProperty(methodName)) {
            routeMiddleware.push(...validations[methodName].rules.map((rule) => rule()));
            routeMiddleware.push(middlewareHandler(options.middleware.validator));
        }

        router[route.method].apply(router, [route.url, ...routeMiddleware, routeHandler]);
    }
    app.use(url, router);
    return app;
}

const getApiRoute = (ApiRoute: any): ExpressClass => {
    try {
        return Container.get(ApiRoute);
    } catch (_a) {
        return new ApiRoute();
    }
};
