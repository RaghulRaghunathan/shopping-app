import { Request, Response, NextFunction } from 'express';
import { ApiResult } from './result';
import { Messages } from './messages';

export interface RequestX extends Request {}

export interface ResponseX extends Response {
    ok(result: ApiResult): void;
    error(result: ApiResult): void;
    apiNotFound(): void;
    serverError(error: any): void;
    validationError(result: ApiResult): void;
}

export interface NextFunctionX extends NextFunction {}

export interface ApiMiddlewareOptions {
    version: string;
    messages?: Messages;
}
