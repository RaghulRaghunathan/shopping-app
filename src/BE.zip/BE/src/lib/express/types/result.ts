export interface ApiResult {
    httpStatus?: number;
    messageCode: number;
    message: string;
    data: any;
}
