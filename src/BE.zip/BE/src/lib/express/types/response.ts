import { ApiResult } from './result';

export interface ApiResponse extends ApiResult {
    version: string;
}
