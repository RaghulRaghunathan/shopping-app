import { RequestHandler } from 'express';
import { RequestX, ResponseX, NextFunctionX, ApiMiddlewareOptions } from '../types/express';
import { ApiResult, ApiResponse } from '../types';
import { exception, setMessages } from './api-result';

const createApiResponse = (version: string, result: ApiResult): ApiResponse => {
    if (result.httpStatus) delete result.httpStatus;

    const response: ApiResponse = {
        version: version,
        ...result,
    };
    return response;
};

export const apiMiddleware: Function = (options: ApiMiddlewareOptions): RequestHandler => {
    if (options.messages) setMessages(options.messages);

    return (_req: RequestX, res: ResponseX, next: NextFunctionX): void => {
        res.ok = (result: ApiResult): void => {
            res.status(result.httpStatus || 200);
            res.json(createApiResponse(options.version, result));
        };

        res.error = (result: ApiResult): void => {
            res.status(result.httpStatus || 400);
            res.json(createApiResponse(options.version, result));
        };

        res.apiNotFound = (): void => {
            res.status(404);
            res.json(createApiResponse(options.version, exception('Api not found')));
        };

        res.serverError = (err: any): void => {
            res.status(err.status || 500).json(
                createApiResponse(options.version, exception(err.message)),
            );
        };

        res.validationError = (result: ApiResult): void => {
            res.status(422);
            res.json(createApiResponse(options.version, result));
        };

        next();
    };
};

export const metaDataMiddleware: RequestHandler = (
    req: RequestX,
    _res: ResponseX,
    next: NextFunctionX,
): void => {
    const reqData: any = req;
    if (reqData?.body?.hasOwnProperty?.('_version'))
        reqData.body._version = !isNaN(parseInt(reqData.body['_version']))
            ? parseInt(reqData.body['_version'])
            : null;
    else if (reqData?.query?.hasOwnProperty?.('_version'))
        reqData.query._version = !isNaN(parseInt(reqData.query['_version']))
            ? parseInt(reqData.query['_version'])
            : null;
    next();
};
