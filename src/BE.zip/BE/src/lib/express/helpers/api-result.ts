import { Messages, HttpStatus } from '../types/messages';
import { ApiResult } from '../types/result';

let messages: Messages = {};
export const setMessages = (_messages: Messages) => {
    messages = _messages;
};

const defaultOptions: any = {
    messageCode: null,
    message: null,
    httpStatus: HttpStatus.OK,
};

const messageFormat = (message: string, values: any) => {
    if (!values) return message;
    return message.replace(
        /\{(\w+)}/g,
        function (txt: string, key: string) {
            if (values.hasOwnProperty(key)) return values[key];
            return txt;
        }.bind(this),
    );
};

const createResult = (messageCode: number, data: any, options: any = {}): ApiResult => {
    let message: string = options?.message;
    let httpStatus: number = options?.httpStatus;

    if (messages.hasOwnProperty(messageCode)) {
        message = message ?? messages[messageCode].message;
        httpStatus = httpStatus ?? messages[messageCode].httpStatus;
    } else {
        httpStatus = httpStatus ?? defaultOptions.httpStatus;
    }

    //In order to configure dynamic values (i.e: Message format => "{key} success")
    if (message && options?.params) message = messageFormat(message, options.params);

    const result: ApiResult = {
        messageCode,
        message,
        data: data ? data : null,
        httpStatus,
    };

    return result;
};

export const take = (messageCode: number, data?: any, options?: any): ApiResult => {
    return createResult(messageCode, data, options);
};

export const exception = (error: string | any): ApiResult => {
    if (error.httpStatus) return error;
    const message = typeof error !== 'string' && error.message ? error.message : error;
    return createResult(1002, { errors: message ? [message] : [] });
};
