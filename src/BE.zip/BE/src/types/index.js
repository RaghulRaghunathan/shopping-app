// Types of common
