import { Request } from 'express';
import { ApiRoutes, ApiResult, POST } from '../lib/express';
import { Callback } from '../controllers/callback';

@ApiRoutes('/callback')
export class CallbackRoutes {
    private callback: Callback;

    @POST('/tour')
    public getBulkOrders(req: Request): Promise<ApiResult> {
        return this.getInstance().updateTour(req);
    }

    @POST('/order-status')
    public getOrder(req: Request): Promise<ApiResult> {
        return this.getInstance().updateOrderStatus(req);
    }

    private getInstance(): Callback {
        if (!this.callback) this.callback = new Callback();
        return this.callback;
    }
}
