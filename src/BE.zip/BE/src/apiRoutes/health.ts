import { Request } from 'express';
import { ApiRoutes, GET, ApiResult, Validate } from '../lib/express';
import { Health } from '../controllers/health';
import { forHealthCode } from '../rules';

@ApiRoutes('/health')
export class HealthRoutes {
    private health: Health;

    @GET('/')
    public getHealth(req: Request): Promise<ApiResult> {
        return this.getInstance().getHealth(req);
    }

    //Validation Example
    @GET('/code/:code?')
    @Validate([forHealthCode])
    public checkHealthCode(req: Request): Promise<ApiResult> {
        return this.getInstance().checkHealthCode(req);
    }

    private getInstance(): Health {
        if (!this.health) this.health = new Health();
        return this.health;
    }
}
