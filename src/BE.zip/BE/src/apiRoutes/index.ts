import { Express, Router } from 'express';
import { attachApiRoutes } from '../lib/express';
import { AuthMiddleware } from '../middlewares/auth';
import { ValidatorMiddleware } from '../middlewares/validator';
import { HealthRoutes } from './health';
import { CallbackRoutes } from './callback';

export const combineApiRoutes = (app: Express) => {
    const healthApiRouter = Router({ mergeParams: true });
    attachApiRoutes(healthApiRouter, [HealthRoutes], {});

    const apiRouter = Router({ mergeParams: true });
    attachApiRoutes(apiRouter, [CallbackRoutes], {
        middleware: {
            auth: AuthMiddleware,
            validator: ValidatorMiddleware,
        },
    });

    app.use('/', healthApiRouter);
    app.use('/v1/client/:clientId', apiRouter);
};
