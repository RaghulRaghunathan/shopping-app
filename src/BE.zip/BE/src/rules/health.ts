import { check, ValidationChain } from 'express-validator';

export const forHealthCode = (): ValidationChain[] => [
    check('code', 'Code is required').notEmpty(),
    check('code', 'Invalid code').equals('9999'),
];
