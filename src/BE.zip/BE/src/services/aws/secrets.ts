/* eslint-disable @typescript-eslint/no-explicit-any */
import { config, SecretsManager } from 'aws-sdk';
import logger from '../../helpers/logger';
import { AppConfig, configReader } from '../../config';
import { awsS3 } from './s3';

export class SecretReader {
    private static instance: SecretReader;
    private appConfig: AppConfig;
    public secretValues: any = null;

    constructor() {
        this.appConfig = configReader.get();
    }

    public static getInstance(): SecretReader {
        if (!SecretReader.instance) SecretReader.instance = new SecretReader();
        return SecretReader.instance;
    }

    public get(): any {
        return this.secretValues;
    }

    public async init(): Promise<void> {
        try {
            const secretName: any = this.appConfig.aws.secretName;

            const client = new SecretsManager({
                region: 'ap-south-1',
            });

            client.getSecretValue({ SecretId: secretName }, (err: any, data: any) => {
                if (err) {
                    logger.error('[AWS] error occurred while pulling secrets: '.concat(err));
                    throw err;
                } else {
                    if ('SecretString' in data) {
                        this.secretValues = JSON.parse(data.SecretString);
                        this.initDependencies();
                    } else {
                        logger.error(
                            '[AWS] secret type is incorrect. data received: '.concat(data),
                        );
                        process.exit(1);
                    }
                }
            });
        } catch (ex: any) {
            logger.error('[AWS] error occurred at pulling secrets layer: exiting app '.concat(ex));
            process.exit(1);
        }
    }

    private initDependencies = async () => {
        await awsS3.init();
    };
}

export const secretReader = SecretReader.getInstance();
