/* eslint-disable @typescript-eslint/no-explicit-any */
import { S3 } from 'aws-sdk';
import logger from '../../helpers/logger';
import { secretReader } from './secrets';

export class AWSS3 {
    private static instance: AWSS3;
    public s3Bucket: any = null;

    public static getInstance(): AWSS3 {
        if (!AWSS3.instance) AWSS3.instance = new AWSS3();
        return AWSS3.instance;
    }

    public async init(): Promise<void> {
        try {
            const secretValues = secretReader?.secretValues;
            this.s3Bucket = new S3({
                accessKeyId: secretValues?.s3_access_key_id,
                secretAccessKey: secretValues?.s3_secret_access_key,
                region: secretValues?.s3_region,
            });
            logger.info('[AWS] S3 bucket connection created successfully');
        } catch (ex: any) {
            logger.error('[AWS] error occurred on S3 bucket connection: '.concat(ex));
        }
    }

    uploadObject = (data: any, contentType: any, path: any): Promise<any> => {
        return new Promise(function (resolve) {
            const secretValues = secretReader?.secretValues;
            const config: any = {
                Bucket: secretValues?.s3_endpoint,
                Body: data,
                ContentType: contentType,
                Key: path,
            };
            awsS3.s3Bucket.putObject(config, function (err: any, data: any) {
                if (err) {
                    const message = `[AWS_S3] upload failed ${JSON.stringify(err)}`;
                    resolve({ status: false, data: message, path });
                }
                resolve({ status: true, data, path });
            });
        });
    };
}

export const awsS3 = AWSS3.getInstance();
