import request from '../common/axios';
import { AppConfig, configReader } from '../../config';

export class LandmarkAPI {
    private appConfig: AppConfig;

    constructor() {
        this.appConfig = configReader.get();
    }

    private setBaseConfiguration = (clientId: any, authorization: any): any => {
        const baseUrl = this.appConfig.landmark.baseUrl;

        let baseConfig: any = {
            baseURL: `${baseUrl}/apps/gdmsacknowledgement`,
            headers: { 'x-ibm-client-id': clientId },
        };

        if (authorization) baseConfig.headers['Authorization'] = authorization;

        return baseConfig;
    };

    public postTourCallbackAPI = (data: any, clientId: any, authorization: any): Promise<any> => {
        const baseConfig = this.setBaseConfiguration(clientId, authorization);
        const additionalConfig = {
            method: 'post',
            url: `/tours/events/callback`,
            data,
        };
        const config = { ...baseConfig, ...additionalConfig };
        return request(config);
    };
}
