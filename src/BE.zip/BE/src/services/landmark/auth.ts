import request from '../common/axios';
import qs from 'qs';
import { AppConfig, configReader } from '../../config';

export class LandmarkAuthAPI {
    private appConfig: AppConfig;

    constructor() {
        this.appConfig = configReader.get();
    }

    private setBaseConfiguration = (): any => {
        const baseUrl = this.appConfig.landmark.authBaseUrl;

        let baseConfig: any = {
            baseURL: `${baseUrl}/oauth2`,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        };

        return baseConfig;
    };

    public getTokenAPI = (requestObject: object): Promise<any> => {
        const baseConfig = this.setBaseConfiguration();
        const additionalConfig = {
            method: 'post',
            url: `token`,
            data: qs.stringify(requestObject),
        };
        const config = { ...baseConfig, ...additionalConfig };
        return request(config);
    };
}
