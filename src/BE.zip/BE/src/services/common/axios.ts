/* eslint-disable @typescript-eslint/no-explicit-any */
import axios from 'axios';
import logger from '../../helpers/logger';

/**
 * Makes an HTTP call to external services with given Axios configuration
 *
 * @param {any} config - Axios configuration that is needed to make external HTTP call
 * @returns {Promise} Axios HTTP call response
 *
 */
const request = async (config: any): Promise<any> => {
    return new Promise((resolve) => {
        axios(config)
            .then((response) => {
                resolve({
                    status: true,
                    code: response.status,
                    headers: response.headers,
                    reqData: { params: config?.params, body: config?.body },
                    data: response?.data,
                });
            })
            .catch(({ response = {} }) => {
                const data = JSON.stringify(response?.data);
                logger.error(`[API] ${response.status} ${config.method} ${config.url} ${data}`);
                resolve({
                    status: false,
                    code: response.status,
                    headers: response.headers,
                    reqData: { params: config?.params, body: config?.body },
                    data: response?.data,
                });
            });
    });
};

export default request;
