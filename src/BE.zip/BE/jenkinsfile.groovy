@Library('sharedLibrary@master') _
import com.locus.utils.tools.Pulumi
import com.locus.SharedLibrary

if (BRANCH_NAME != "master") {
  return
}
String pulumiStack = env.getEnvironment().containsKey('PULUMI_STACK') ? PULUMI_STACK : 'PreProd'

node('general-slave') {
  def sharedLibrary = new SharedLibrary(this)

  stage('Checkout') {
    sharedLibrary.checkout("git@github.com:locus-taxy/zepto-lily-be.git", BRANCH_NAME)
  }

  stage("Deploy") {
      Pulumi pulumi = new Pulumi(this)
      withCredentials([[$class: 'AmazonWebServicesCredentialsBinding', accessKeyVariable: 'AWS_ACCESS_KEY_ID', credentialsId: "aws-taxybackend", secretKeyVariable: 'AWS_SECRET_ACCESS_KEY'], string(credentialsId: 'pulumi-passphrase', variable: 'PULUMI_CONFIG_PASSPHRASE')]) {
          pulumi.deploy("zepto-lily-be", pulumiStack, "locus-pulumi-prod", "us-east-1", "pulumi")
      }
  }
}
