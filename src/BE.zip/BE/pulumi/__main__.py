from pulumi_aws import ecr
import pulumi_docker as docker
from pulumi import Config
import base64
import git
from locus_pulumi_aws.ecs import (
    EcsTaskDefinationArgs,
    containerDefinationArgs,
    EcsApp,
    EcsCluster,
    EcsServiceArgs,
    EcsAlbArgs,
)

config = Config()

tags = config.require_object("tags")

repo = ecr.Repository(config.require(key="ecs_name"), tags=tags)

ecr.LifecyclePolicy(
    config.require(key="ecs_name"),
    repository=repo.name,
    policy="""
        {
            "rules":[
                {
                    "rulePriority":1,
                    "description":"Remove old resource",
                    "selection":{
                        "tagStatus":"any",
                        "countType":"imageCountMoreThan",
                        "countNumber":3
                    },
                    "action":{
                        "type":"expire"
                    }
                }
            ]
        }
    """,
)


def getRegistryInfo(registryid):
    creds = ecr.get_credentials(registry_id=registryid)
    decoded = base64.b64decode(creds.authorization_token).decode()
    parts = decoded.split(":")
    if len(parts) != 2:
        raise Exception("Invalid credentials")
    return docker.ImageRegistry(creds.proxy_endpoint, parts[0], parts[1])


def getGitSha() -> str:
    try:
        repo = git.Repo(search_parent_directories=True)
        return repo.git.rev_parse(repo.head.object.hexsha, short=6)
    except git.exc.InvalidGitRepositoryError:
        return "latest"


registry_info = repo.registry_id.apply(getRegistryInfo)

# Build and publish the image.
ecr_image = docker.Image(
    config.require(key="ecs_name"),
    build=docker.DockerBuild(
        context="../"
    ),
    image_name=repo.repository_url.apply(lambda server: f"{server}:{getGitSha()}"),
    registry=registry_info,
)

cluster = EcsCluster(config.require(key="ecs_name"), tags=tags)

app = EcsApp(
    config.require(key="ecs_name"),
    taskDefinationArgs=EcsTaskDefinationArgs(
        ecsRoleArn=config.require("ecsRoleArn"),
        executionRoleArn=config.require("executionRoleArn"),
        containerArgs=[
            containerDefinationArgs(
                image=ecr_image.image_name,
                port=[3008],
                environmentVariable=[config.require_object("EnvVariables")]
            )
        ],
    ),
    ecsCluster=cluster,
    serviceArgs=EcsServiceArgs(
        loadBalancerArgs=EcsAlbArgs(
            albArn=config.require("albarn"),
            hostName=config.require("domainName"),
            healthCheckPath="/health"
        ),
        taskCount=1
    ),
    tags=tags,
    NRKey=config.require("nrKey")
)
