module.exports = {
  bracketSpacing: true,
  printWidth: 100,
  useTabs: false,
  overrides: [
    {
      files: ["*.ts"],
      options: {
        arrowParens: "always",
        singleQuote: true,
        semi: true,
        trailingComma: "all",
        quoteProps: "as-needed",
        bracketSameLine: false,
        tabWidth: 4,
      },
    },
    {
      files: "*.json",
      options: {
        tabWidth: 2,
      },
    },
  ],
};
