@Library('sharedLibrary@master') _
import com.locus.StaticWebsites
import com.locus.utils.tools.Yarn

node("general-slave") {
    String projectName = "locus-tracking-fe"
    String branch = env.getEnvironment().containsKey('BRANCH_NAME') ? BRANCH_NAME : 'master'

    StaticWebsites trackingFE = new StaticWebsites(this, projectName)
    trackingFE.abortPreviousJob()
    trackingFE.setStaticWebsitesConfig()
    stage('Checkout') {
        trackingFE.checkout("git@github.com:locus-taxy/locus-tracking-fe.git", branch)
        trackingFE.credentialScan()
    }

    stage('SonarScan'){
        String args = "-Dsonar.projectKey=${projectName} -Dsonar.branch.name=${ branch} -Dsonar.sources=src"
        trackingFE.sonarScan(args)
    }

    stage('Build') {
        String build_command = "build-devo"
        if (branch == "master") {
        build_command = env.getEnvironment().containsKey('YARN_BUILD_COMMAND') ? YARN_BUILD_COMMAND : 'build-pre-prod'
        }
        def dockerImage = docker.image('902898050868.dkr.ecr.us-east-1.amazonaws.com/volta:1.0.4')
        Yarn.run(this, dockerImage, {
        Yarn.yarnInstall(this)
        sh "yarn ${build_command}"
        })
    }

    stage('Deploy') {
        if (branch == "alt-master"){
            String directory = trackingFE.slugify(branch)
            trackingFE.devoStackConfig.s3Prefix = "locus-tracking-fe/${directory}"
            trackingFE.devoStackConfig.distributionId = "E2QEI8KJ90H4U6"
            trackingFE.deploy("build/", trackingFE.devoStackConfig, true)
        } 
        if(branch == "master" ) {
            String stack = env.getEnvironment().containsKey('STACK') ? STACK : 'aws-pre-prod'
            trackingFE.deploy("build/", stack)
        }
    }
}
