export const CONFIG = {
    LOCUS: {
        LILY_BASE_URL: process.env.REACT_APP_LILY_API,
        CLIENT_ID: process.env.REACT_APP_CLIENT_ID,
    },
    MAP: {
        API_KEY: process.env.REACT_APP_MAP_API_KEY,
        DEFAULT_ZOOM: 12,
        CENTER_LAT_LNG: { lat: 12.9255548, lng: 77.6368199 },
    },
    MANUAL_CLIENT_ID: process.env.REACT_APP_MANUAL_CLIENT_ID,
};
