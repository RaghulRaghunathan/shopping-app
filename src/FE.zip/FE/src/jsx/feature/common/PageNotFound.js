import React, { useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import RoutesEnum from '../../constants/RoutesEnum';
import Button from './StyledComponent/Button';
import CustomError from './StyledComponent/CustomError';

const PageNotFound = () => {
    const navigate = useNavigate();
    const { t } = useTranslation();

    const handleSubmit = useCallback(() => {
        navigate(`${RoutesEnum.LandingPage}?trackingId=`);
    }, [navigate]);

    return (
        <React.Fragment>
            <CustomError
                code={404}
                title={t('pageNotFoundTitle')}
                description={t('pageNotFoundDescription')}
            >
                <Button variant="contained" onClick={handleSubmit}>
                    {t('goToHomeScreen')}
                </Button>
            </CustomError>
        </React.Fragment>
    );
};

export default PageNotFound;
