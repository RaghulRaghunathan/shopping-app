import React from 'react';
import { Box, CircularProgress } from '@mui/material';
import styled from 'styled-components';

const BoxContainer = styled(Box)`
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
`;

const CircularLoader = () => {
    return (
        <BoxContainer color="link">
            <CircularProgress color="primary" />
        </BoxContainer>
    );
};

export default CircularLoader;
