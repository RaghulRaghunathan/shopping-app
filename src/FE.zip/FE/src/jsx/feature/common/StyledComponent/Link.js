import React from 'react';
import { Link as MuiLink } from '@mui/material';
import styled from 'styled-components';

const LinkContainer = styled(MuiLink)`
    cursor: pointer;
`;

const Link = ({ onClick, children }) => {
    return (
        <LinkContainer onClick={onClick} color="link">
            {children}
        </LinkContainer>
    );
};

export default Link;
