import { IconButton, Snackbar, Typography } from '@mui/material';
import { Box } from '@mui/system';
import React from 'react';
import styled from 'styled-components';
import CloseIcon from '@mui/icons-material/Close';
import NotificationsIcon from '@mui/icons-material/Notifications';

const Notification = ({ message, onClose }) => {
    return (
        <Box display="flex" alignItems="center" paddingY="12px">
            <IconButton
                style={{
                    margin: '0 12px',
                    color: '#3392ff',
                    width: '24px',
                    height: '24px',
                }}
                size="small"
                aria-label="close"
                onClick={() => {}}
            >
                <NotificationsIcon
                    fontSize="small"
                    style={{ width: '24px', height: '24px' }}
                />
            </IconButton>
            <Typography variant="title4" color="#FFFFFF">
                {message}
            </Typography>
            <IconButton
                style={{
                    margin: '0 24px',
                    color: '#67718E',
                    width: '24px',
                    height: '24px',
                }}
                size="small"
                aria-label="close"
                color="inherit"
                onClick={onClose}
            >
                <CloseIcon
                    fontSize="small"
                    style={{ width: '20px', height: '20px' }}
                />
            </IconButton>
        </Box>
    );
};

const SnackbarBox = styled(Snackbar)`
    max-width: 500px;
    width: fit-content !important;
    margin: 0 8px;

    .MuiSnackbarContent-root {
        padding: 0;
        border-left: 6px solid #3392ff;
        background-color: #111318 !important;
        min-width: auto;

        .MuiSnackbarContent-message {
            padding: 0;
        }

        .MuiSnackbarContent-action {
            padding: 0;
        }
    }
`;

const SnackBar = ({ isOpen, message, onClose }) => {
    return (
        <SnackbarBox
            open={isOpen}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
            autoHideDuration={6000}
            onClose={onClose}
            action={<Notification message={message} onClose={onClose} />}
        />
    );
};

export default SnackBar;
