import React from 'react';
import { Button as MuiButton, Typography } from '@mui/material';

const Button = ({ onClick, children, variant, ...props }) => (
    <MuiButton variant={variant} onClick={onClick} {...props}>
        <Typography variant="button">{children}</Typography>
    </MuiButton>
);

export default Button;
