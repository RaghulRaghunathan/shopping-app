import React from 'react';
import { Box } from '@mui/material';
import styled from 'styled-components';

const MainContainer = styled(Box)`
    display: flex;
    flex-direction: column;
    align-items: center;
`;

const ErrorCode = styled(Box)`
    font-size: 7rem;
    font-weight: 600;
    color: #343947;
    line-height: 1.4;
    text-align: center;
`;

const TitleBox = styled(Box)`
    color: #343947f2;
    font-size: 2rem;
    line-height: 1.4;
    margin-bottom: 10px;
    text-align: center;
`;

const TitleDescription = styled(Box)`
    color: #343947f2;
    font-size: 0.8rem;
    line-height: 1.6;
    margin-bottom: 27px;
    max-width: 460px;
    text-align: center;
`;

const CustomError = ({ code, title, description, children }) => (
    <MainContainer>
        <ErrorCode>{code}</ErrorCode>
        <TitleBox>{title}</TitleBox>
        <TitleDescription>{description}</TitleDescription>
        <Box>{children}</Box>
    </MainContainer>
);

export default CustomError;
