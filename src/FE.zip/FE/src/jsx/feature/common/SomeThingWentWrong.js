import React, { useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { useDispatch } from 'react-redux';
import {
    useNavigate,
    useSearchParams,
    createSearchParams,
} from 'react-router-dom';
import RoutesEnum from '../../constants/RoutesEnum';
import { setBodyComponent } from '../../container/appSlice';
import Button from './StyledComponent/Button';
import CustomError from './StyledComponent/CustomError';

const SomeThingWentWrong = () => {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const dispatch = useDispatch();
    const { t } = useTranslation();

    const handleGoToHomeScreen = useCallback(() => {
        dispatch(setBodyComponent(null));
        navigate(
            `${RoutesEnum.LandingPage}?${createSearchParams(searchParams)}`,
        );
    }, [dispatch, navigate, searchParams]);

    return (
        <CustomError
            code={500}
            title="Something Went Wrong"
            description="Please, try again later!!!"
        >
            <Button variant="contained" onClick={handleGoToHomeScreen}>
                {t('goToHomeScreen')}
            </Button>
        </CustomError>
    );
};

export default SomeThingWentWrong;
