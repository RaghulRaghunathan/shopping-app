import * as React from 'react';
import { Box, LinearProgress } from '@mui/material';
import styled from 'styled-components';
import ClientContext from '../../container/ClientContext';

const MainContainer = styled(Box)`
    display: flex;
    align-items: center;
    justify-content: center;
    /* Height adjustment in order to make loading center based on responsive */
    height: calc(100% - 40px);
    ${(props) => props.theme.breakpoints.up('sm')} {
        height: calc(100% - 60px);
    }
    ${(props) => props.theme.breakpoints.up('lg')} {
        height: calc(100% - 80px);
    }
`;

const ImageBox = styled('img')`
    height: ${(props) => props.theme.styleConfig.loadingLogoHeight.xs};
    margin: 0 20px 10px 20px;
    ${(props) => props.theme.breakpoints.up('sm')} {
        height: ${(props) => props.theme.styleConfig.loadingLogoHeight.sm};
        margin: 0 30px 15px 30px;
    }
    ${(props) => props.theme.breakpoints.up('lg')} {
        height: ${(props) => props.theme.styleConfig.loadingLogoHeight.lg};
        margin: 0 40px 20px 40px;
    }
`;

const LinearProgressBox = ({ className }) => (
    <Box className={className}>
        <LinearProgress
            classes={{
                root: 'loader',
                barColorPrimary: 'barColorPrimary',
            }}
        />
    </Box>
);

const LinearProgressBoxContainer = styled(LinearProgressBox)`
    .loader {
        border-radius: 4px;
        background-color: #eaeaea !important;
    }
    .barColorPrimary {
        background-color: ${(props) => props.theme.primary};
    }
`;

const LoadingPage = () => {
    const { clientTheme } = React.useContext(ClientContext);

    return (
        <MainContainer>
            <Box>
                <ImageBox
                    src={clientTheme.brand.logoUrl}
                    alt={clientTheme.brand.logoImgAlt}
                />
                <LinearProgressBoxContainer />
            </Box>
        </MainContainer>
    );
};

export default LoadingPage;
