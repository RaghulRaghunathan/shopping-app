import { Box, Typography } from '@mui/material';
import React from 'react';
import { useTranslation } from 'react-i18next';
import styled from 'styled-components';
import ClientContext from '../../container/ClientContext';
import Link from '../common/StyledComponent/Link';

const BoxContainer = styled(Box)`
    align-items: center;
    padding: 0 ${(props) => props.theme.styleConfig.appContainerPadding.lg};
    height: ${(props) => props.theme.styleConfig.footerHeight.lg};
    ${(props) => props.theme.breakpoints.up('sm')} {
        display: flex;
    }
    ${(props) => props.theme.breakpoints.down('lg')} {
        padding: 0 ${(props) => props.theme.styleConfig.appContainerPadding.md};
    }
    ${(props) => props.theme.breakpoints.down('sm')} {
        padding: 10px
            ${(props) => props.theme.styleConfig.appContainerPadding.sm};
        text-align: center;
        height: calc(
            ${(props) => props.theme.styleConfig.footerHeight.sm} - 20px
        );
    }
`;

const TypographyContainer = styled(Typography)`
    ${(props) => props.theme.breakpoints.down('sm')} {
        padding: 2px 0;
    }
    ${(props) => props.type === 'tac' && `{margin-left: auto !important;}`}
`;

const AppFooter = () => {
    const { clientTheme } = React.useContext(ClientContext);
    const { t } = useTranslation();

    return (
        <BoxContainer>
            <TypographyContainer variant="body2">
                {clientTheme.brand.copyRights}
            </TypographyContainer>
            <TypographyContainer variant="body2">
                <Link>{t('privacyPolicy')}</Link>
            </TypographyContainer>
            <TypographyContainer variant="body2" type="tac">
                <Link>{t('termsCondition')}</Link>
            </TypographyContainer>
        </BoxContainer>
    );
};

export default AppFooter;
