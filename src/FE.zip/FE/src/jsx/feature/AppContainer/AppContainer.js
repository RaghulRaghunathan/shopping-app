import { Box } from '@mui/material';
import React from 'react';
import styled from 'styled-components';
import { AppBody } from '../AppBody';
import { AppHeader } from '../AppHeader';
import AppFooter from './AppFooter';

const ScrollContainer = styled(Box)`
    overflow: auto;
    height: calc(
        100vh - ${({ theme }) => theme.styleConfig.headerMenuHeight.lg} -
            ${({ theme }) => theme.styleConfig.breadcrumbsHeight.lg}
    );
    ${(props) => props.theme.breakpoints.down('sm')} {
        height: calc(
            100vh - ${({ theme }) => theme.styleConfig.headerMenuHeight.sm} -
                ${({ theme }) => theme.styleConfig.breadcrumbsHeight.sm}
        );
    }
`;

const AppContainer = () => {
    return (
        <Box>
            <AppHeader />
            <ScrollContainer>
                <AppBody />
                <AppFooter />
            </ScrollContainer>
        </Box>
    );
};

export default AppContainer;
