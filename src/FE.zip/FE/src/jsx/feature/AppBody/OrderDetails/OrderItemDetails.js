import React, { useCallback } from 'react';
import { Box, Typography } from '@mui/material';
import moment from 'moment-timezone';
import { useTranslation } from 'react-i18next';
import {
    useNavigate,
    useSearchParams,
    createSearchParams,
} from 'react-router-dom';
import styled from 'styled-components';
import RoutesEnum from '../../../constants/RoutesEnum';
import ClientContext from '../../../container/ClientContext';
import {
    BoxStyleContainer,
    Divider,
    Splitter,
    StatusBar,
} from '../../AppBody/styles';
import Button from '../../common/StyledComponent/Button';
import {
    isStorePickUpOrder,
    showDeliveryDateInfo,
    useGetServiceStatus,
} from '../../../helpers/utils';

const MainContainer = styled(BoxStyleContainer)`
    align-items: center;
    ${(props) => props.theme.breakpoints.down('sm')} {
        padding: 12px;
    }
    ${(props) => props.theme.breakpoints.up('sm')} {
        display: flex;
        padding: 16px;
    }
    ${(props) => props.theme.breakpoints.down('xl')} {
        &.showCarousel {
            display: block;
        }
    }
`;

const SplitterBox = styled(Box)`
    ${(props) => props.theme.breakpoints.down('sm')} {
        display: none;
    }
    ${(props) => props.theme.breakpoints.down('xl')} {
        &.showCarousel {
            display: none;
        }
    }
`;

const DividerBox = styled(Box)`
    ${(props) => props.theme.breakpoints.up('sm')} {
        display: none;
    }
    ${(props) => props.theme.breakpoints.down('xl')} {
        &.showCarousel {
            display: block;
        }
    }
`;

const OrderDetail = styled(Box)`
    display: flex;
    align-items: center;
    ${(props) => props.theme.breakpoints.down('sm')} {
        justify-content: space-between;
    }
    ${(props) => props.theme.breakpoints.down('xl')} {
        &.showCarousel {
            justify-content: space-between;
        }
    }
`;

const DeliveryDetailBox = styled(Box)`
    margin-right: 32px;
`;

const ButtonBox = styled(Box)`
    display: flex;
    justify-content: right;
    ${(props) => props.theme.breakpoints.up('sm')} {
        margin-top: 4px;
    }
`;

const OrderItemDetails = ({ data }) => {
    const {
        clientTheme: { showCarousel },
    } = React.useContext(ClientContext);
    const navigate = useNavigate();
    const { t } = useTranslation();
    const [searchParams] = useSearchParams();

    const handleSummaryRedirect = useCallback(() => {
        const trackingIds = searchParams.get('trackingId');
        searchParams.set('trackingId', data.orderId);
        navigate(`${RoutesEnum.Summary}?${createSearchParams(searchParams)}`, {
            state: { trackingIds },
        });
    }, [navigate, searchParams, data]);

    const orderStatus = useGetServiceStatus(
        data.type,
        data.orderStatus,
        data.orderSubStatus,
    );

    return (
        <MainContainer
            marginTop="16px"
            className={showCarousel === 'true' && 'showCarousel'}
        >
            <OrderDetail className={showCarousel === 'true' && 'showCarousel'}>
                <Box>
                    <Typography variant="body2" paddingBottom="2px">
                        {t(data.type)}
                    </Typography>
                    <Typography variant="title3">{data.orderId}</Typography>
                </Box>
                <SplitterBox
                    className={showCarousel === 'true' && 'showCarousel'}
                >
                    <Splitter />
                </SplitterBox>
                <StatusBar statustype={data.orderStatus}>
                    <Typography variant="caption2">{orderStatus}</Typography>
                </StatusBar>
            </OrderDetail>
            {showDeliveryDateInfo(data.orderStatus) && (
                <React.Fragment>
                    <DividerBox
                        className={showCarousel === 'true' && 'showCarousel'}
                    >
                        <Divider />
                    </DividerBox>
                    <Box display="flex" marginLeft="auto">
                        <DeliveryDetailBox>
                            <Typography variant="body2" paddingBottom="2px">
                                {isStorePickUpOrder(data.type)
                                    ? t('pickupDate')
                                    : t('deliveryDate')}
                            </Typography>
                            <Typography variant="caption1">
                                {moment(data.deliveryDate).format('YYYY-MM-DD')}
                            </Typography>
                        </DeliveryDetailBox>
                        <DeliveryDetailBox>
                            <Typography variant="body2" paddingBottom="2px">
                                {showDeliveryDateInfo(data.orderStatus) &&
                                isStorePickUpOrder(data.type)
                                    ? t('pickupSlot')
                                    : t('deliverySlot')}
                            </Typography>
                            <Typography variant="caption1">{`${moment(
                                data.slot?.start,
                            ).format('hh:mma')} - ${moment(
                                data.slot?.end,
                            ).format('hh:mma')}`}</Typography>
                        </DeliveryDetailBox>
                    </Box>
                </React.Fragment>
            )}
            <ButtonBox
                {...(!showDeliveryDateInfo(data.orderStatus) && {
                    marginLeft: 'auto',
                })}
            >
                <Button variant="text" onClick={handleSummaryRedirect}>
                    {t('viewDetails')}
                </Button>
            </ButtonBox>
        </MainContainer>
    );
};

export default OrderItemDetails;
