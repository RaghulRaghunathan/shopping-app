import OrderDetails from './OrderDetails';

export { OrderDetails };
