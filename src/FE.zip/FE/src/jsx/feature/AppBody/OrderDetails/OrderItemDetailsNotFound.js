import React from 'react';
import { Box, Typography } from '@mui/material';
import { useTranslation } from 'react-i18next';
import styled from 'styled-components';
import { BoxStyleContainer, Divider, Splitter } from '../../AppBody/styles';

const MainContainer = styled(BoxStyleContainer)`
    margin-top: 16px;
    align-items: center;
    ${(props) => props.theme.breakpoints.down('sm')} {
        padding: 12px;
    }
    ${(props) => props.theme.breakpoints.up('sm')} {
        display: flex;
        padding: 16px;
    }
`;

const SplitterBox = styled(Box)`
    ${(props) => props.theme.breakpoints.down('sm')} {
        display: none;
    }
`;

const DividerBox = styled(Box)`
    ${(props) => props.theme.breakpoints.up('sm')} {
        display: none;
    }
    ${(props) => props.theme.breakpoints.down('xl')} {
        &.showCarousel {
            display: block;
        }
    }
`;

const OrderItemDetailsNotFound = ({ orderId }) => {
    const { t } = useTranslation();
    return (
        <MainContainer>
            <React.Fragment>
                <Typography variant="title3">{orderId}</Typography>
                <SplitterBox>
                    <Splitter />
                </SplitterBox>
                <DividerBox>
                    <Divider />
                </DividerBox>
            </React.Fragment>
            <Box>
                <Typography variant="body2" color="#DC2518">
                    {t('noOrderFoundMsg')}
                </Typography>
                <Typography variant="body2" color="#DC2518">
                    {t('checkOrderNoMsg')}
                </Typography>
            </Box>
        </MainContainer>
    );
};

export default OrderItemDetailsNotFound;
