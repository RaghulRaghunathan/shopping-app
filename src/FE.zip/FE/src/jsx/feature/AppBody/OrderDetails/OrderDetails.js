import React, { useCallback, useEffect, useMemo } from 'react';
import { Box, Typography, useMediaQuery } from '@mui/material';
import styled, { useTheme } from 'styled-components';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import {
    useNavigate,
    useSearchParams,
    createSearchParams,
} from 'react-router-dom';
import moment from 'moment-timezone';
import Button from '../../common/StyledComponent/Button';
import OrderItemDetails from './OrderItemDetails';
import OrderItemDetailsNotFound from './OrderItemDetailsNotFound';
import Carousel from '../Common/Carousel';
import ClientContext from '../../../container/ClientContext';
import { useGetOrderDetailsMutation } from '../../../services/lily';
import { setBodyComponent, setTrackingIds } from '../../../container/appSlice';
import {
    ArrowBackIosNewIcon,
    BoxStyleContainer,
    CarouselContainerBottom,
    CarouselContainerSide,
    IconBox,
} from '../styles';
import { isStorePickUpOrder } from '../../../helpers/utils';

const TitleContainer = styled(BoxStyleContainer)`
    align-items: center;
    display: flex;
    padding: 16px;
    ${(props) => props.theme.breakpoints.down('sm')} {
        padding: 0;
        box-shadow: none;
        background-color: unset;
    }
`;

const TNOButton = styled(Button)`
    margin-left: auto !important;
    ${(props) => props.show === 'true' && `{display: none !important;}`}
    ${(props) => props.theme.breakpoints.down('sm')} {
        width: 100%;
        margin-top: 16px !important;
        background-color: #ffffff !important;
    }
`;

const BodyContainer = styled(Box)`
    ${(props) => props.theme.breakpoints.up('sm')} {
        display: flex !important;
    }
`;

const CarouselContainer1 = styled(CarouselContainerSide)`
    ${(props) => props.norecords === 'true' && `{display: none;}`}
`;

const CarouselContainer2 = styled(CarouselContainerBottom)`
    ${(props) => props.norecords === 'true' && `{display: block;}`}
`;

const OrderDetails = () => {
    const {
        clientTheme: { showCarousel },
        clientId,
    } = React.useContext(ClientContext);
    const theme = useTheme();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { t } = useTranslation();
    const { trackingIds } = useSelector((state) => state.app);
    const [searchParams] = useSearchParams();
    const isSmallScreen = useMediaQuery(theme.breakpoints.down('sm'));

    const [getOrderDetails, { isLoading, data: resData, isError }] =
        useGetOrderDetailsMutation();

    useEffect(() => {
        if (trackingIds.length <= 0) return;
        const payload = { orderIds: trackingIds };

        getOrderDetails({ clientId, payload });
    }, [clientId, getOrderDetails, trackingIds]);

    useEffect(() => {
        dispatch(setBodyComponent(isLoading ? 'loading' : null));
    }, [dispatch, isLoading]);

    useEffect(() => {
        if (isError) dispatch(setBodyComponent('someThingWentWrong'));
    }, [dispatch, isError]);

    const handleLandingPageRedirect = useCallback(() => {
        navigate(`/?${createSearchParams(searchParams)}`);
    }, [navigate, searchParams]);

    const handleLandingPageRedirectClearAll = useCallback(() => {
        dispatch(setTrackingIds([]));
        searchParams.set('trackingId', '');
        navigate(`/?${createSearchParams(searchParams)}`);
    }, [navigate, searchParams, dispatch]);

    const orderByIds = useMemo(() => {
        const dataList = {};
        resData?.data?.orders.forEach((item) => {
            dataList[item.id] = {
                id: item.id,
                type: item.type,
                orderId: item.id,
                orderStatus: item.orderStatus,
                orderSubStatus: item.orderSubStatus,
                deliveryDate: moment(item.slot?.start).format('YYYY-MM-DD'),
                slot: item.slot,
            };

            if (isStorePickUpOrder(item.type))
                dataList[item.id].slot = {
                    start: moment('10', 'hh').format(),
                    end: moment('17', 'hh').format(),
                };
        });
        return dataList;
    }, [resData]);

    return (
        <Box
            display={trackingIds.length > 0 && resData === undefined && 'none'}
        >
            <TitleContainer>
                <IconBox onClick={handleLandingPageRedirect}>
                    <ArrowBackIosNewIcon />
                </IconBox>
                <Typography variant="title1" padding="0 8px">
                    {t('deliveryStatusList')}
                    {trackingIds.length === 0 && (
                        <Typography variant="body2" color="#DC2518">
                            {t('checkOrderNoMsg')}
                        </Typography>
                    )}
                </Typography>
                <TNOButton
                    variant="outlined"
                    show={isSmallScreen.toString()}
                    onClick={handleLandingPageRedirectClearAll}
                >
                    {t('trackNewOrders')}
                </TNOButton>
            </TitleContainer>
            <BodyContainer>
                <Box width="-webkit-fill-available">
                    {trackingIds.map((item) => {
                        return orderByIds[item] ? (
                            <OrderItemDetails
                                key={item}
                                data={orderByIds[item]}
                            />
                        ) : (
                            <OrderItemDetailsNotFound
                                key={item}
                                orderId={item}
                            />
                        );
                    })}
                </Box>
                <CarouselContainer1
                    show={showCarousel}
                    marginTop="16px"
                    norecords={trackingIds.length === 0 ? 'true' : 'false'}
                >
                    <Carousel />
                </CarouselContainer1>
            </BodyContainer>
            <TNOButton
                variant="outlined"
                show={(!isSmallScreen).toString()}
                onClick={handleLandingPageRedirectClearAll}
            >
                {t('trackNewOrders')}
            </TNOButton>
            <CarouselContainer2
                show={showCarousel}
                norecords={trackingIds.length === 0 ? 'true' : 'false'}
            >
                <Carousel
                    settings={{
                        variableWidth: true,
                        adaptiveHeight: true,
                        centerMode: true,
                    }}
                    customStyle={{ margin: '0 8px' }}
                />
            </CarouselContainer2>
        </Box>
    );
};

export default OrderDetails;
