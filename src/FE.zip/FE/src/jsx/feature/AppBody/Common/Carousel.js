import React from 'react';
import Slider from 'react-slick';
import { Box } from '@mui/material';
import styled from 'styled-components';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import ClientContext from '../../../container/ClientContext';

const Container = styled(Box)`
    max-width: 100%;
    max-width: 100%;
    .slick-dots {
        bottom: 10px;
        button:before {
            font-size: 8px;
            opacity: 1 !important;
            color: #f3f4f6 !important;
        }
        li.slick-active {
            button:before {
                color: #8992a9 !important;
            }
        }
    }
`;

const ImageBox = styled('img')`
    border-radius: 8px;
    width: 300px;
    height: 390px;
`;

const defaultSettings = {
    dots: true,
    arrows: false,
    autoplaySpeed: 3000,
    autoplay: true,
    draggable: true,
    infinite: true,
    swipeToSlide: true,
    slidesToShow: 1,
};

const Carousel = ({ settings, customStyle }) => {
    const { clientTheme } = React.useContext(ClientContext);

    return (
        <Container>
            <Slider {...defaultSettings} {...settings}>
                {clientTheme.brand.adsImgUrl?.map((item, i) => (
                    <Box key={i}>
                        <ImageBox src={item} style={{ ...customStyle }} />
                    </Box>
                ))}
            </Slider>
        </Container>
    );
};

export default Carousel;
