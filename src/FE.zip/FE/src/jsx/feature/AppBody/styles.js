import { Box } from '@mui/material';
import ArrowBackIosNewIconMui from '@mui/icons-material/ArrowBackIosNew';
import styled from 'styled-components';
import { STATUS_CODE_ONLY_BORDER, STATUS_COLOR } from '../../constants';

export const BoxStyleContainer = styled(Box)`
    border-radius: 8px;
    box-shadow: 0px 0px 4px rgba(17, 19, 24, 0.16);
    background-color: #ffffff;
`;

export const Splitter = styled(Box)`
    background: #e7e9ee;
    width: 1px;
    height: 16px;
    margin: 0 8px;
`;

export const Divider = styled(Box)`
    width: 100%;
    height: 1px;
    background-color: #e7e9ee;
    margin: 4px 0;
`;

export const IconBox = styled(Box)`
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
`;

export const ArrowBackIosNewIcon = styled(ArrowBackIosNewIconMui)`
    width: 20px;
    height: 20px;
    color: #67718e;
`;

export const StatusBar = styled(Box)`
    height: 20px;
    background-color: ${(props) => {
        const status = props.statustype.toLowerCase();
        const isWhiteBG = STATUS_CODE_ONLY_BORDER.includes(status);
        return isWhiteBG ? '#ffffff' : STATUS_COLOR[status];
    }};
    display: flex;
    align-items: center;
    padding: 0 6px;
    border-radius: 2px;
    border: 2px solid ${(props) => STATUS_COLOR[props.statustype.toLowerCase()]};
    width: fit-content;
`;

export const CarouselContainerSide = styled(BoxStyleContainer)`
    height: 390px;
    padding: 0;
    margin-left: 32px;
    min-width: 300px;
    width: 300px;
    ${(props) => props.show !== 'true' && `{display: none !important;}`}
    ${(props) => props.theme.breakpoints.down('lg')} {
        display: none;
    }
`;

export const CarouselContainerBottom = styled(Box)`
    margin-top: 32px;
    ${(props) => props.show !== 'true' && `{display: none !important;}`}
    ${(props) => props.theme.breakpoints.down('sm')} {
        margin-top: 16px;
    }
    ${(props) => props.theme.breakpoints.up('lg')} {
        display: none;
    }
`;
