import { Box, Typography } from '@mui/material';
import moment from 'moment-timezone';
import React, { useCallback, useEffect, useMemo } from 'react';
import styled from 'styled-components';
import DoDisturbAltIcon from '@mui/icons-material/DoDisturbAlt';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';
import EventRepeatIcon from '@mui/icons-material/EventRepeat';
import Grid from '@mui/material/Unstable_Grid2/Grid2';
import {
    useNavigate,
    createSearchParams,
    useSearchParams,
    useLocation,
} from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import { Divider, Splitter, IconBox } from '../../AppBody/styles';
import Button from '../../common/StyledComponent/Button';
import RoutesEnum from '../../../constants/RoutesEnum';
import {
    useCancelOrderMutation,
    useUpdateOnTheWayMutation,
} from '../../../services/lily';
import { setBodyComponent } from '../../../container/appSlice';
import ClientContext from '../../../container/ClientContext';
import { BoxStyleContainer, ArrowBackIosNewIcon, StatusBar } from '../styles';
import { ALLOW_CANCEL_STATUS_LIST } from '../../../constants';
import OrderItemDetailsNotFound from './OrderSummaryNotFound';
import SnackBar from '../../common/StyledComponent/SnackBar';
import {
    isStorePickUpOrder,
    allowOnTheWayUpdate,
    showDeliveryDateInfo,
    useGetServiceStatus,
} from '../../../helpers/utils';

const OrderDetail = styled(Box)`
    display: flex;
    align-items: center;
    ${(props) => props.theme.breakpoints.down('sm')} {
        justify-content: space-between;
    }
`;

const SplitterBox = styled(Box)`
    ${(props) => props.theme.breakpoints.down('sm')} {
        display: none;
    }
    ${(props) => props.theme.breakpoints.down('xl')} {
        &.showCarousel {
            display: none;
        }
    }
`;

const DividerBox = styled(Box)`
    ${(props) => props.theme.breakpoints.up('sm')} {
        display: none;
    }
    ${(props) => props.theme.breakpoints.down('xl')} {
        &.showCarousel {
            display: block;
        }
    }
`;

const DeliveryDetailBox = styled(Box)`
    display: flex;
    ${(props) => props.theme.breakpoints.down('sm')} {
        justify-content: space-between;
    }
    ${(props) => props.theme.breakpoints.up('sm')} {
        margin: 0 32px;
    }
`;

const BackBtn = styled(Box)`
    cursor: pointer;
    ${(props) => props.theme.breakpoints.down('sm')} {
        display: none;
    }
`;

const ButtonContainer = styled(Box)`
    margin-left: auto;
    text-align: end;
    ${(props) => props.theme.breakpoints.down('sm')} {
        display: none;
    }
`;

const ButtonContainerSx = styled(Box)`
    ${(props) => props.theme.breakpoints.up('sm')} {
        display: none;
    }
`;

const BoxContainerMain = styled(BoxStyleContainer)`
    align-items: center;
    ${(props) => props.theme.breakpoints.down('sm')} {
        padding: 12px;
    }
    ${(props) => props.theme.breakpoints.up('sm')} {
        display: flex;
        padding: 16px;
    }
    ${(props) => props.theme.breakpoints.down('xl')} {
        display: block;
    }
`;

const SampleBox = styled(Box)`
    display: flex;
    justify-content: space-between;
    ${(props) => props.theme.breakpoints.down('sm')} {
        display: block;
    }
`;

const BtnDividerBox = styled(Box)`
    display: block;
    margin-bottom: 8px;
    ${(props) => props.theme.breakpoints.down('sm')} {
        display: none;
    }
    ${(props) => props.theme.breakpoints.up('xl')} {
        display: none;
    }
`;

const OrderSummaryHeader = ({
    orderDetails: data,
    orderId,
    getOrderDetails,
}) => {
    const { clientId } = React.useContext(ClientContext);
    const [snackBarMessage, setSnackBarMessage] = React.useState(null);
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const location = useLocation();
    const { t } = useTranslation();
    const dispatch = useDispatch();

    const [
        cancelOrder,
        {
            isLoading: isCancelling,
            isSuccess: successCancel,
            isError: errorCancel,
        },
    ] = useCancelOrderMutation();

    const [
        updateOrderOnTheWay,
        {
            isLoading: isUpdating,
            isSuccess: successOnTheWay,
            isError: errorOnTheWay,
        },
    ] = useUpdateOnTheWayMutation();

    useEffect(() => {
        if (successCancel || successOnTheWay) {
            getOrderDetails(orderId);
            const message = successCancel
                ? t('cancelSuccessMessage', { orderId })
                : t('onTheWaySuccessMessage', { orderId });
            setSnackBarMessage(message);
        }
    }, [t, successCancel, successOnTheWay, orderId, getOrderDetails]);

    useEffect(() => {
        if (isCancelling || isUpdating) dispatch(setBodyComponent('loading'));
    }, [dispatch, isCancelling, isUpdating]);

    useEffect(() => {
        if (errorCancel || errorOnTheWay)
            dispatch(setBodyComponent('someThingWentWrong'));
    }, [dispatch, errorCancel, errorOnTheWay]);

    const handleDetailPageRedirect = useCallback(() => {
        if (location.state?.trackingIds)
            searchParams.set('trackingId', location.state.trackingIds);
        navigate(`${RoutesEnum.Details}?${createSearchParams(searchParams)}`);
    }, [navigate, searchParams, location]);

    const handleCancel = useCallback(() => {
        cancelOrder({ clientId, orderId });
    }, [clientId, orderId, cancelOrder]);

    const handleOnTheWay = useCallback(() => {
        updateOrderOnTheWay({ clientId, orderId });
    }, [clientId, orderId, updateOrderOnTheWay]);

    const { showCancel, showReschedule, showOnTheWay } = useMemo(() => {
        let showCancel = false;
        let showOnTheWay = false;

        if (ALLOW_CANCEL_STATUS_LIST.includes(data?.orderStatus))
            showCancel = true;
        if (allowOnTheWayUpdate(data?.type, data?.orderStatus))
            showOnTheWay = true;

        return { showCancel, showReschedule: false, showOnTheWay };
    }, [data]);

    const orderStatus = useGetServiceStatus(
        data?.type,
        data?.orderStatus,
        data?.orderSubStatus,
    );

    return (
        <React.Fragment>
            <BoxContainerMain>
                <SnackBar
                    isOpen={snackBarMessage ? true : false}
                    message={snackBarMessage}
                    onClose={() => setSnackBarMessage(null)}
                />
                {!data ? (
                    <SampleBox>
                        <OrderItemDetailsNotFound
                            handleDetailPageRedirect={handleDetailPageRedirect}
                            orderId={orderId}
                        />
                    </SampleBox>
                ) : (
                    <React.Fragment>
                        <SampleBox>
                            <OrderDetail>
                                <BackBtn onClick={handleDetailPageRedirect}>
                                    <IconBox>
                                        <ArrowBackIosNewIcon />
                                    </IconBox>
                                </BackBtn>
                                <Box>
                                    <Typography
                                        variant="body2"
                                        paddingBottom="2px"
                                    >
                                        {t(data.type)}
                                    </Typography>
                                    <Typography variant="title3">
                                        {data.orderId}
                                    </Typography>
                                </Box>
                                <SplitterBox>
                                    <Splitter />
                                </SplitterBox>
                                <StatusBar statustype={data.orderStatus}>
                                    <Typography variant="caption2">
                                        {orderStatus}
                                    </Typography>
                                </StatusBar>
                            </OrderDetail>
                            {showDeliveryDateInfo(data.orderStatus) && (
                                <React.Fragment>
                                    <DividerBox>
                                        <Divider />
                                    </DividerBox>
                                    <DeliveryDetailBox>
                                        <Box>
                                            <Typography
                                                variant="body2"
                                                paddingBottom="2px"
                                            >
                                                {isStorePickUpOrder(data.type)
                                                    ? t('pickupDate')
                                                    : t('deliveryDate')}
                                            </Typography>
                                            <Typography variant="caption1">
                                                {moment(
                                                    data.deliveryDate,
                                                ).format('YYYY-MM-DD')}
                                            </Typography>
                                        </Box>
                                        <Box marginLeft="32px">
                                            <Typography
                                                variant="body2"
                                                paddingBottom="2px"
                                            >
                                                {isStorePickUpOrder(data.type)
                                                    ? t('pickupSlot')
                                                    : t('deliverySlot')}
                                            </Typography>
                                            <Typography variant="caption1">{`${moment(
                                                data.slot?.start,
                                            ).format('hh:mma')} - ${moment(
                                                data.slot?.end,
                                            ).format('hh:mma')}`}</Typography>
                                        </Box>
                                    </DeliveryDetailBox>
                                </React.Fragment>
                            )}
                        </SampleBox>
                        {(showCancel || showReschedule || showOnTheWay) && (
                            <BtnDividerBox>
                                <Divider />
                            </BtnDividerBox>
                        )}
                        <ButtonContainer>
                            <Button
                                style={{
                                    marginLeft: '16px',
                                    display: !showCancel && 'none',
                                }}
                                color="error"
                                variant="outlined"
                                startIcon={<DoDisturbAltIcon />}
                                onClick={handleCancel}
                            >
                                {t('cancel')}
                            </Button>
                            <Button
                                style={{
                                    marginLeft: '16px',
                                    display: !showReschedule && 'none',
                                }}
                                variant="outlined"
                                startIcon={<EventRepeatIcon />}
                            >
                                {t('reschedule')}
                            </Button>
                            <Button
                                style={{
                                    marginLeft: '16px',
                                    display: !showOnTheWay && 'none',
                                }}
                                variant="outlined"
                                startIcon={<DirectionsCarIcon />}
                                onClick={handleOnTheWay}
                            >
                                {t('onTheWay')}
                            </Button>
                        </ButtonContainer>
                    </React.Fragment>
                )}
            </BoxContainerMain>
            <ButtonContainerSx>
                <Grid width={'100%'} sm={12}>
                    <Grid display={!showOnTheWay && 'none'} marginTop="16px">
                        <Button
                            style={{
                                width: '100%',
                            }}
                            variant="outlined"
                            startIcon={<DirectionsCarIcon />}
                            onClick={handleOnTheWay}
                        >
                            {t('onTheWay')}
                        </Button>
                    </Grid>
                    <Grid display="flex" sm={12} columnGap={4}>
                        <Grid
                            width={showReschedule ? '50%' : '100%'}
                            display={!showCancel && 'none'}
                            marginTop="16px"
                        >
                            <Button
                                style={{
                                    width: '100%',
                                    marginRight: '16px',
                                }}
                                color="error"
                                variant="outlined"
                                startIcon={<DoDisturbAltIcon />}
                                onClick={handleCancel}
                            >
                                {t('cancel')}
                            </Button>
                        </Grid>
                        <Grid
                            width={showCancel ? '50%' : '100%'}
                            display={!showReschedule && 'none'}
                            marginTop="16px"
                        >
                            <Button
                                style={{
                                    width: '100%',
                                    marginRight: '16px',
                                }}
                                variant="outlined"
                                startIcon={<EventRepeatIcon />}
                            >
                                {t('reschedule')}
                            </Button>
                        </Grid>
                    </Grid>
                </Grid>
            </ButtonContainerSx>
        </React.Fragment>
    );
};

export default OrderSummaryHeader;
