import React from 'react';
import { Box, Typography } from '@mui/material';
import { useTranslation } from 'react-i18next';
import styled from 'styled-components';
import {
    Divider,
    Splitter,
    IconBox,
    ArrowBackIosNewIcon,
} from '../../AppBody/styles';

const OrderDetailNotFound = styled(Box)`
    display: flex;
    align-items: center;
    ${(props) => props.theme.breakpoints.down('sm')} {
        display: block;
    }
`;

const BackBtn = styled(Box)`
    cursor: pointer;
    ${(props) => props.theme.breakpoints.down('sm')} {
        display: none;
    }
`;

const SplitterBox = styled(Box)`
    ${(props) => props.theme.breakpoints.down('sm')} {
        display: none;
    }
    ${(props) => props.theme.breakpoints.down('xl')} {
        &.showCarousel {
            display: none;
        }
    }
`;

const DividerBox = styled(Box)`
    ${(props) => props.theme.breakpoints.up('sm')} {
        display: none;
    }
    ${(props) => props.theme.breakpoints.down('xl')} {
        &.showCarousel {
            display: block;
        }
    }
`;

const OrderSummaryNotFound = ({ orderId, handleDetailPageRedirect }) => {
    const { t } = useTranslation();
    return (
        <OrderDetailNotFound>
            <BackBtn onClick={handleDetailPageRedirect}>
                <IconBox>
                    <ArrowBackIosNewIcon />
                </IconBox>
            </BackBtn>
            {orderId ? (
                <React.Fragment>
                    <Typography variant="title3" paddingLeft="8px">
                        {orderId}
                    </Typography>
                    <SplitterBox>
                        <Splitter />
                    </SplitterBox>
                    <DividerBox>
                        <Divider />
                    </DividerBox>
                    <Box>
                        <Typography variant="body2" color="#DC2518">
                            {t('noOrderFoundMsg')}
                        </Typography>
                        <Typography variant="body2" color="#DC2518">
                            {t('checkOrderNoMsg')}
                        </Typography>
                    </Box>
                </React.Fragment>
            ) : (
                <Box padding="0 8px">
                    <Typography variant="title1">
                        {`${t('deliverySlipNumber')}: `}
                    </Typography>
                    <Typography variant="body2" color="#DC2518">
                        {t('checkOrderNoMsg')}
                    </Typography>
                </Box>
            )}
        </OrderDetailNotFound>
    );
};

export default OrderSummaryNotFound;
