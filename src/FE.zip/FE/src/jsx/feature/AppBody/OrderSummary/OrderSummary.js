import { Box, Typography } from '@mui/material';
import React, { useCallback, useEffect, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import styled from 'styled-components';
import moment from 'moment';
import {
    useNavigate,
    useSearchParams,
    createSearchParams,
    useLocation,
} from 'react-router-dom';
import MapContainer from './MapContainer';
import OrderSummaryHeader from './OrderSummaryHeader';
import OrderItemSummary from './OrderItemSummary';
import AddressDetails from './AddressDetails';
import Carousel from '../Common/Carousel';
import RoutesEnum from '../../../constants/RoutesEnum';
import ClientContext from '../../../container/ClientContext';
import { useGetOrderMutation } from '../../../services/lily';
import { setBodyComponent } from '../../../container/appSlice';
import {
    BoxStyleContainer,
    CarouselContainerBottom,
    CarouselContainerSide,
    IconBox,
    ArrowBackIosNewIcon,
} from '../styles';
import {
    showHomebaseDetails,
    isStorePickUpOrder,
} from '../../../helpers/utils';

const TitleBoxContainerSummary = styled(BoxStyleContainer)`
    align-items: center;
    display: flex;
    padding: 16px;
    margin-bottom: 16px;
    ${(props) => props.theme.breakpoints.up('sm')} {
        display: none;
    }
    ${(props) => props.theme.breakpoints.down('sm')} {
        padding: 0;
        box-shadow: none;
        background-color: unset;
    }
`;

const BodyContainerMain = styled(Box)`
    display: flex !important;
`;

const BoxContainer = styled(BoxStyleContainer)`
    align-items: center;
    ${(props) => props.theme.breakpoints.down('sm')} {
        padding: 12px;
    }
    ${(props) => props.theme.breakpoints.up('sm')} {
        display: flex;
        padding: 16px;
    }
`;

const BodyContainer = styled(BoxContainer)`
    align-items: start;
    margin-top: 32px;
    padding: 0;
    width: -webkit-fill-available;
    ${(props) => props.theme.breakpoints.up('sm')} {
        height: 390px;
    }
    ${(props) => props.theme.breakpoints.down('sm')} {
        margin-top: 16px;
    }
    ${(props) => props.showmapbox !== 'true' && `{height: unset !important;}`}
`;

const StatusListContainer = styled(Box)`
    padding-top: 16px;
    padding-bottom: 16px;
    margin-left: 16px;
    ${(props) => props.theme.breakpoints.up('sm')} {
        width: calc(100% - 350px);
        max-height: calc(390px - 16px - 16px);
        overflow: auto;
    }
    ${(props) => props.showmapbox !== 'true' && `{width: 100% !important;}`}
`;

const AddressBox = styled(BoxContainer)`
    ${(props) => props.theme.breakpoints.up('sm')} {
        display: none;
    }
    ${(props) => props.theme.breakpoints.down('sm')} {
        margin-top: 16px;
    }
    ${(props) => props.showmapbox !== 'true' && `{display: none !important;}`}
`;

const MapBox = styled(Box)`
    ${(props) => props.theme.breakpoints.up('sm')} {
        width: 350px;
    }
    ${(props) => props.theme.breakpoints.down('sm')} {
        display: none;
    }
    ${(props) => props.showmapbox !== 'true' && `{display: none !important;}`}
`;

const CarouselContainer1 = styled(CarouselContainerSide)`
    margin-top: 32px;
    ${(props) => props.theme.breakpoints.down('xl')} {
        display: none;
    }
`;

const CarouselContainer2 = styled(CarouselContainerBottom)`
    ${(props) => props.theme.breakpoints.down('xl')} {
        display: block;
    }
    ${(props) => props.norecords === 'true' && `{display: block;}`}
`;

const OrderSummary = () => {
    const {
        clientTheme: { showCarousel },
        clientId,
    } = React.useContext(ClientContext);
    const navigate = useNavigate();
    const { t } = useTranslation();
    const location = useLocation();
    const [searchParams] = useSearchParams();
    const dispatch = useDispatch();
    const { trackingIds } = useSelector((state) => state.app);

    const [getOrderDetailsService, { isLoading, data: resData, isError }] =
        useGetOrderMutation();

    const getOrderDetails = useCallback(
        (orderId) => {
            getOrderDetailsService({
                clientId,
                orderId,
            });
        },
        [clientId, getOrderDetailsService],
    );

    useEffect(() => {
        if (trackingIds.length <= 0) return;
        getOrderDetails(trackingIds[0]);
    }, [getOrderDetails, trackingIds]);

    useEffect(() => {
        dispatch(setBodyComponent(isLoading ? 'loading' : null));
    }, [dispatch, isLoading]);

    useEffect(() => {
        if (isError) dispatch(setBodyComponent('someThingWentWrong'));
    }, [dispatch, isError]);

    const handleBackBtn = useCallback(() => {
        if (location.state?.trackingIds)
            searchParams.set('trackingId', location.state.trackingIds);
        navigate(`${RoutesEnum.Details}?${createSearchParams(searchParams)}`);
    }, [navigate, searchParams, location]);

    const orderDetails = useMemo(() => {
        let orderData = null;
        const data = resData?.data;
        if (!data) return orderData;

        orderData = {
            id: data.id,
            type: data.type,
            orderId: data.id,
            orderStatus: data.orderStatus,
            orderSubStatus: data.orderSubStatus,
            deliveryDate: moment(data.slot?.start).format('YYYY-MM-DD'),
            slot: data.slot,
        };

        if (isStorePickUpOrder(data.type))
            orderData.slot = {
                start: moment('10', 'hh').format(),
                end: moment('17', 'hh').format(),
            };

        orderData.homebase = {
            name: data.homebase?.name,
            mobileNumber: data.homebase?.contact?.phoneNumber?.phoneNumber,
            address: data.homebase?.address?.formattedAddress,
            slot: data.homebaseSlot,
            latLng: data.homebase?.latLng,
        };
        orderData.statusList = data.timeline
            .map((item, index) => ({
                id: index,
                status: item.orderStatus,
                subStatus: data.orderSubStatus,
                date: item.updatedOn,
            }))
            .sort((a, b) => moment(b.date) - moment(a.date));

        return orderData;
    }, [resData]);

    return (
        <Box
            display={trackingIds.length > 0 && resData === undefined && 'none'}
        >
            <TitleBoxContainerSummary
                className={showCarousel === 'true' && 'showCarousel'}
            >
                <IconBox onClick={handleBackBtn}>
                    <ArrowBackIosNewIcon />
                </IconBox>
                <Typography variant="title1" padding="0 8px">
                    {`${t('deliverySlipNumber')}: ${trackingIds[0] || ''}`}
                </Typography>
            </TitleBoxContainerSummary>
            <OrderSummaryHeader
                orderDetails={orderDetails}
                orderId={trackingIds[0]}
                getOrderDetails={getOrderDetails}
            />
            <AddressBox
                showmapbox={showHomebaseDetails(
                    orderDetails?.type,
                    orderDetails?.orderStatus,
                ).toString()}
            >
                <AddressDetails
                    data={orderDetails?.homebase}
                    key={trackingIds[0]}
                />
            </AddressBox>
            <BodyContainerMain display={!orderDetails && 'none !important'}>
                <BodyContainer
                    showmapbox={showHomebaseDetails(
                        orderDetails?.type,
                        orderDetails?.orderStatus,
                    ).toString()}
                >
                    <StatusListContainer
                        showmapbox={showHomebaseDetails(
                            orderDetails?.type,
                            orderDetails?.orderStatus,
                        ).toString()}
                    >
                        {orderDetails?.statusList?.map((item, index) => (
                            <OrderItemSummary
                                key={item.id}
                                type={orderDetails?.type}
                                data={item}
                                isLast={index === 0}
                            />
                        ))}
                    </StatusListContainer>
                    <MapBox
                        showmapbox={showHomebaseDetails(
                            orderDetails?.type,
                            orderDetails?.orderStatus,
                        ).toString()}
                    >
                        <MapContainer data={orderDetails?.homebase} showInfo />
                    </MapBox>
                </BodyContainer>
                <CarouselContainer1 show={showCarousel}>
                    <Carousel />
                </CarouselContainer1>
            </BodyContainerMain>
            <CarouselContainer2
                show={showCarousel}
                norecords={orderDetails ? 'false' : 'true'}
            >
                <Carousel
                    settings={{
                        variableWidth: true,
                        adaptiveHeight: true,
                        centerMode: true,
                    }}
                    customStyle={{ margin: '0 8px' }}
                />
            </CarouselContainer2>
        </Box>
    );
};

export default OrderSummary;
