import { Box, Typography } from '@mui/material';
import Grid from '@mui/material/Unstable_Grid2';
import React from 'react';
import styled from 'styled-components';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import PanoramaFishEyeIcon from '@mui/icons-material/PanoramaFishEye';
import moment from 'moment-timezone';
import { ORDER_PERFORMED_STATUS_LIST } from '../../../constants';
import {
    useGetServiceDescription,
    useGetServiceStatus,
} from '../../../helpers/utils';

const IconBox = styled(CheckCircleIcon)`
    margin-top: 1px;
    width: 16.5px !important;
    height: 16.5px !important;
    color: ${(props) => props.theme.palette.success.main};
`;

const OngoingStatusIconBox = styled(PanoramaFishEyeIcon)`
    margin-top: 1px;
    width: 16.5px !important;
    height: 16.5px !important;
    color: ${(props) => props.theme.palette.primary.main};
`;

const LineBox = styled(Box)`
    display: flex;
    flex: 1;
    width: 1px;
    margin-top: 8px;
    margin-right: 1px;
    background-color: #e7e9ee;
`;

const OrderItemSummary = ({ type, data, isLast }) => {
    const status = useGetServiceStatus(type, data.status, data.subStatus);
    const statusDescription = useGetServiceDescription(
        type,
        data.status,
        data.subStatus,
    );
    return (
        <Box display="flex" marginBottom="16px">
            <Box display="flex" flexDirection="column" alignItems="center">
                {!ORDER_PERFORMED_STATUS_LIST.includes(data.status) &&
                isLast ? (
                    <OngoingStatusIconBox />
                ) : (
                    <IconBox />
                )}
                <LineBox />
            </Box>
            <Box width="100%" paddingX="8px">
                <Typography variant="title3">{status}</Typography>
                <Grid
                    container
                    alignItems="center"
                    columnGap={6}
                    pt="6px"
                    ml="16px"
                >
                    <Grid pt="2px" width="300px" pr="50px">
                        <Typography variant="caption1">
                            {statusDescription}
                        </Typography>
                    </Grid>
                    <Grid container pt="2px" columnGap={6} pr="20px">
                        <Grid>
                            <Typography variant="body2">
                                {moment(data.date).format('Do MMMM, hh:mm A')}
                            </Typography>
                        </Grid>
                    </Grid>
                </Grid>
            </Box>
        </Box>
    );
};

export default OrderItemSummary;
