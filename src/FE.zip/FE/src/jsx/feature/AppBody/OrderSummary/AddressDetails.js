import { Box, Button, Typography } from '@mui/material';
import React from 'react';
import styled from 'styled-components';
import moment from 'moment-timezone';
import ArrowDropDownCircleIcon from '@mui/icons-material/ArrowDropDownCircle';
import LocalPhoneIcon from '@mui/icons-material/LocalPhone';
import FmdGoodIcon from '@mui/icons-material/FmdGood';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import NearMeIcon from '@mui/icons-material/NearMe';
import { useTranslation } from 'react-i18next';
import Grid from '@mui/material/Unstable_Grid2/Grid2';
import MapContainer from './MapContainer';

const AddressIconBox = styled(Box)`
    margin-right: 8px;
    color: ${(props) => props.theme.palette.dark.main};
    ${(props) => props.theme.breakpoints.down('sm')} {
        display: none;
    }
`;

const MapContainerSx = styled(Box)`
    ${(props) => props.theme.breakpoints.up('sm')} {
        display: none;
    }
`;

const ContactBtnContainer = styled(Grid)`
    margin-top: 16px;
    display: flex;
    ${(props) => props.theme.breakpoints.up('sm')} {
        display: none;
    }
`;

const AddressDetails = ({ data }) => {
    const { t } = useTranslation();

    return (
        <Box>
            <Box display="flex" justifyContent={'space-between'}>
                <Box>
                    <Box display="flex" marginBottom="8px">
                        <AddressIconBox>
                            <ArrowDropDownCircleIcon
                                style={{ width: '16px', height: '16px' }}
                            />
                        </AddressIconBox>
                        <Typography variant="title3">{data?.name}</Typography>
                    </Box>
                    <Box display="flex" marginBottom="8px">
                        <AddressIconBox>
                            <LocalPhoneIcon
                                style={{ width: '16px', height: '16px' }}
                            />
                        </AddressIconBox>
                        <Typography variant="body2" color="#0072f5">
                            {data?.mobileNumber}
                        </Typography>
                    </Box>
                    <Box display="flex" marginBottom="8px">
                        <AddressIconBox>
                            <FmdGoodIcon
                                style={{ width: '16px', height: '16px' }}
                            />
                        </AddressIconBox>
                        <Typography variant="body2">{data?.address}</Typography>
                    </Box>
                    <Box display="flex" marginBottom="8px">
                        <AddressIconBox>
                            <AccessTimeIcon
                                style={{ width: '16px', height: '16px' }}
                            />
                        </AddressIconBox>
                        <Typography variant="body2">{`${moment(
                            data?.slot?.start,
                        ).format('hh:mma')} - ${moment(data?.slot?.end).format(
                            'hh:mma',
                        )}`}</Typography>
                    </Box>
                </Box>
                <MapContainerSx width="100px" height="100px">
                    <MapContainer
                        data={data}
                        showInfo={false}
                        style={{ width: '100px', height: '100px' }}
                    />
                </MapContainerSx>
            </Box>
            <ContactBtnContainer sm={12} columnGap={4}>
                <Grid width={'50%'}>
                    <Button
                        href={`tel:${data?.mobileNumber}`}
                        style={{
                            width: '100%',
                            marginRight: '16px',
                        }}
                        variant="outlined"
                        startIcon={<LocalPhoneIcon />}
                    >
                        {t('call')}
                    </Button>
                </Grid>
                <Grid width={'50%'}>
                    <Button
                        style={{
                            width: '100%',
                            marginRight: '16px',
                        }}
                        target="_blank"
                        href={`https://www.google.com/maps/dir/?api=1&destination=${data?.latLng?.lat},${data?.latLng?.lng}`}
                        variant="outlined"
                        startIcon={<NearMeIcon />}
                    >
                        {t('direction')}
                    </Button>
                </Grid>
            </ContactBtnContainer>
        </Box>
    );
};

export default AddressDetails;
