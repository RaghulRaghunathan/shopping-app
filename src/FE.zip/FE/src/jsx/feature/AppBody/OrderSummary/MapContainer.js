import {
    GoogleMap,
    InfoWindow,
    Marker,
    useJsApiLoader,
} from '@react-google-maps/api';
import React from 'react';
import { CONFIG } from '../../../config';
import AddressDetails from './AddressDetails';

const containerStyle = {
    width: '350px',
    height: '390px',
    borderRadius: '0 8px 8px 0',
};

const MapContainer = ({ data, showInfo, style }) => {
    const { isLoaded } = useJsApiLoader({
        id: 'google-map-script',
        googleMapsApiKey: CONFIG.MAP.API_KEY,
    });

    return (
        isLoaded && (
            <GoogleMap
                mapContainerStyle={{ ...containerStyle, ...style }}
                zoom={CONFIG.MAP.DEFAULT_ZOOM}
                center={data?.latLng || CONFIG.MAP.CENTER_LAT_LNG}
                options={{
                    fullscreenControl: false,
                    streetViewControl: false,
                    mapTypeControl: false,
                    clickableIcons: false,
                    keyboardShortcuts: false,
                }}
                mapTypeId="terrain"
            >
                <Marker
                    position={data?.latLng || CONFIG.MAP.CENTER_LAT_LNG}
                    icon={`${process.env.PUBLIC_URL}/assets/images/map-marker.svg`}
                >
                    {showInfo && (
                        <InfoWindow
                            position={data?.latLng || CONFIG.MAP.CENTER_LAT_LNG}
                        >
                            <AddressDetails data={data} />
                        </InfoWindow>
                    )}
                </Marker>
            </GoogleMap>
        )
    );
};

export default MapContainer;
