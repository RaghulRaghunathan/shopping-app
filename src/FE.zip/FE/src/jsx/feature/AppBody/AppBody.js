import { Box } from '@mui/material';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    Routes,
    Route,
    useSearchParams,
    useNavigate,
    useLocation,
    createSearchParams,
} from 'react-router-dom';
import styled from 'styled-components';
import RoutesEnum from '../../constants/RoutesEnum';
import { setBodyComponent, setTrackingIds } from '../../container/appSlice';
import RouteNotFound from '../../routes/RouteNotFound';
import LoadingPage from '../common/LoadingPage';
import SomeThingWentWrong from '../common/SomeThingWentWrong';
import { LandingPage } from './LandingPage';
import { OrderDetails } from './OrderDetails';
import { OrderSummary } from './OrderSummary';

const BoxContainer = styled(Box)`
    display: flex;
    background: #ebf4ff;
    padding: 0 ${({ theme }) => theme.styleConfig.appContainerPadding.lg};
    min-height: calc(
        100vh - ${({ theme }) => theme.styleConfig.headerMenuHeight.lg} -
            ${({ theme }) => theme.styleConfig.breadcrumbsHeight.lg} -
            ${({ theme }) => theme.styleConfig.footerHeight.lg}
    );
    ${(props) => props.theme.breakpoints.down('lg')} {
        padding: 0 ${({ theme }) => theme.styleConfig.appContainerPadding.md};
    }
    ${(props) => props.theme.breakpoints.down('sm')} {
        padding: 0 ${({ theme }) => theme.styleConfig.appContainerPadding.sm};
        min-height: calc(
            100vh - ${({ theme }) => theme.styleConfig.headerMenuHeight.sm} -
                ${({ theme }) => theme.styleConfig.breadcrumbsHeight.sm} -
                ${({ theme }) => theme.styleConfig.footerHeight.sm}
        );
    }
`;

const AppBody = () => {
    const { bodyComponent } = useSelector((state) => state.app);
    const [searchParams] = useSearchParams();
    const location = useLocation();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const trackingIds = searchParams.get('trackingId');

    useEffect(() => {
        if (trackingIds !== null) return;
        searchParams.set('trackingId', '');
        navigate(`${location.pathname}?${createSearchParams(searchParams)}`);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [trackingIds, navigate, searchParams]);

    useEffect(() => {
        if (trackingIds?.length > 0) {
            dispatch(
                setTrackingIds(
                    trackingIds
                        .split(',')
                        .map((item) => item.trim())
                        .filter((item) => item.length > 0),
                ),
            );
        }
    }, [trackingIds, dispatch]);

    useEffect(() => {
        dispatch(setBodyComponent(null));
    }, [dispatch, location]);

    const getComponent = (type) => {
        switch (type) {
            case 'loading':
                return <LoadingPage />;
            case 'someThingWentWrong':
                return <SomeThingWentWrong />;
            default:
                return <React.Fragment />;
        }
    };

    return (
        <BoxContainer>
            <Box
                paddingY="24px"
                width="100%"
                {...(!bodyComponent && { display: 'none' })}
            >
                {getComponent(bodyComponent)}
            </Box>
            <Box
                paddingY="24px"
                width="100%"
                {...(bodyComponent && { display: 'none' })}
            >
                <Routes>
                    <Route
                        path={RoutesEnum.LandingPage}
                        element={<LandingPage />}
                    />
                    <Route
                        path={RoutesEnum.Summary}
                        element={<OrderSummary />}
                    />
                    <Route
                        path={RoutesEnum.Details}
                        element={<OrderDetails />}
                    />
                    <Route path="*" element={<RouteNotFound />} />
                </Routes>
            </Box>
        </BoxContainer>
    );
};

export default AppBody;
