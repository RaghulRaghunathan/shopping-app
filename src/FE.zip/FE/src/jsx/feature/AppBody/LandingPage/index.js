import LandingPage from './LandingPage';

export { LandingPage };
