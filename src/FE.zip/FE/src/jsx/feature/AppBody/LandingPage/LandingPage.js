import { Box, TextField, Typography } from '@mui/material';
import React, { useCallback, useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import {
    useNavigate,
    useSearchParams,
    createSearchParams,
} from 'react-router-dom';
import styled from 'styled-components';
import Button from '../../common/StyledComponent/Button';
import Carousel from '../Common/Carousel';
import { setTrackingIds } from '../../../container/appSlice.js';
import RoutesEnum from '../../../constants/RoutesEnum';
import ClientContext from '../../../container/ClientContext';
import {
    BoxStyleContainer,
    CarouselContainerBottom,
    CarouselContainerSide,
} from '../styles';

const MainContainer = styled(Box)`
    ${(props) => props.theme.breakpoints.up('sm')} {
        display: flex !important;
    }
`;

const BoxContainer = styled(BoxStyleContainer)`
    padding: 32px 32px 50px 32px;
    ${(props) => props.theme.breakpoints.up('sm')} {
        width: 100%;
    }
    ${(props) => props.theme.breakpoints.down('sm')} {
        max-width: 100%;
    }
`;

const LandingPage = () => {
    const {
        clientTheme: { showCarousel },
    } = React.useContext(ClientContext);
    const { trackingIds } = useSelector((state) => state.app);
    const [trackingInputIds, setTrackingInputIds] = useState('');
    const [errorMessage, setErrorMessage] = useState(null);
    const [searchParams] = useSearchParams();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { t } = useTranslation();

    useEffect(() => {
        setTrackingInputIds(trackingIds.join(','));
    }, [trackingIds]);

    const handleSubmit = useCallback(() => {
        const ids = trackingInputIds
            .split(',')
            .map((item) => item.trim())
            .filter((item) => item.length > 0);

        if (ids.length === 0) return setErrorMessage('errorMsgOrderIds');
        if (ids.length > 5) return setErrorMessage('errorMsgOnly5orderIds');
        setErrorMessage(null);

        dispatch(setTrackingIds(ids));
        searchParams.set('trackingId', ids.join(','));
        navigate(`${RoutesEnum.Details}?${createSearchParams(searchParams)}`);
    }, [dispatch, navigate, searchParams, trackingInputIds]);

    const handleChange = useCallback((e) => {
        const data = e.target.value;
        setTrackingInputIds(data);
    }, []);

    const { clientTheme } = React.useContext(ClientContext);
    const getLandingMessage = (messageKey, fallbackMessage) => {
        return clientTheme.brand[messageKey] || t(fallbackMessage);
    };

    return (
        <Box>
            <MainContainer>
                <BoxContainer>
                    <Typography variant="title1" paddingBottom="8px">
                        {t(`trackYourShipment`)}
                    </Typography>
                    <Typography variant="body1" paddingBottom="8px">
                        {getLandingMessage(
                            'landingMessage1',
                            'landingMessage1',
                        )}
                    </Typography>
                    <Typography variant="body1">
                        {getLandingMessage(
                            'landingMessage2',
                            'landingMessage2',
                        )}
                    </Typography>
                    <Box paddingTop="8px" paddingBottom="10px">
                        <TextField
                            label={t(`enterOrderId`)}
                            type="search"
                            variant="standard"
                            onChange={handleChange}
                            value={trackingInputIds}
                            fullWidth
                            required
                            error={errorMessage ? true : false}
                            {...(errorMessage && {
                                helperText: t(errorMessage),
                            })}
                        />
                    </Box>
                    <Typography variant="body2" paddingBottom="16px">
                        {t(`landingInputInfo`)}
                    </Typography>
                    <Button variant="contained" onClick={handleSubmit}>
                        {t(`trackShipment`)}
                    </Button>
                </BoxContainer>
                <CarouselContainerSide show={showCarousel}>
                    <Carousel />
                </CarouselContainerSide>
            </MainContainer>
            <CarouselContainerBottom show={showCarousel}>
                <Carousel
                    settings={{
                        variableWidth: true,
                        adaptiveHeight: true,
                        centerMode: true,
                    }}
                    customStyle={{ margin: '0 8px' }}
                />
            </CarouselContainerBottom>
        </Box>
    );
};

export default LandingPage;
