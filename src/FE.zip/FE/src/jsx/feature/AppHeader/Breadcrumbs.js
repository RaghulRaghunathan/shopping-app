import { Box, Typography, Breadcrumbs as MuiBreadcrumbs } from '@mui/material';
import React, { useState, useEffect, useCallback } from 'react';
import { useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';
import {
    useNavigate,
    createSearchParams,
    useSearchParams,
    useLocation,
} from 'react-router-dom';
import styled from 'styled-components';
import RoutesEnum from '../../constants/RoutesEnum';
import Link from '../common/StyledComponent/Link';

const BoxContainer = styled(Box)`
    display: flex;
    align-items: center;
    padding: 0 ${(props) => props.theme.styleConfig.appContainerPadding.lg};
    height: ${(props) => props.theme.styleConfig.breadcrumbsHeight.lg};
    ${(props) => props.theme.breakpoints.down('lg')} {
        padding: 0 ${(props) => props.theme.styleConfig.appContainerPadding.md};
    }
    ${(props) => props.theme.breakpoints.down('sm')} {
        padding: 0 ${(props) => props.theme.styleConfig.appContainerPadding.sm};
        height: ${(props) => props.theme.styleConfig.breadcrumbsHeight.sm};
    }
`;

const ScrollBoxStyling = styled(Box)`
    overflow: scroll;
    &::-webkit-scrollbar {
        display: none;
    }
`;

const BoxStyling = styled(Box)`
    width: 80px;
    height: 20px;
    right: 0;
    position: absolute;
    background-image: linear-gradient(
        270deg,
        #ffffff 21.11%,
        rgba(255, 255, 255, 0) 107.22%
    ) !important;
`;

const Breadcrumbs = () => {
    const [searchParams] = useSearchParams();
    const { trackingIds } = useSelector((state) => state.app);
    const navigate = useNavigate();
    const location = useLocation();
    const { t } = useTranslation();
    const [active, setActive] = useState(1);

    useEffect(() => {
        if (location.pathname === '/') return setActive(1);
        if (location.pathname === RoutesEnum.Details) return setActive(2);
        if (location.pathname === RoutesEnum.Summary) return setActive(3);
    }, [location.pathname]);

    const handlePageRedirect = useCallback(
        (redirectPathName) => () => {
            if (location.state?.trackingIds)
                searchParams.set('trackingId', location.state.trackingIds);
            navigate(`${redirectPathName}?${createSearchParams(searchParams)}`);
        },
        [navigate, location, searchParams],
    );

    const getLinkComponent = (isActive, name, redirectPath) => {
        return (
            <Typography variant="breadcrumbs">
                {isActive ? (
                    <Link onClick={handlePageRedirect(redirectPath)}>
                        {t(name)}
                    </Link>
                ) : (
                    t(name)
                )}
            </Typography>
        );
    };

    return (
        <BoxContainer>
            <ScrollBoxStyling>
                <Box width="max-content">
                    <BoxStyling />
                    <Box marginRight="50px">
                        <MuiBreadcrumbs>
                            {getLinkComponent(
                                active > 1,
                                'trackYourShipment',
                                RoutesEnum.LandingPage,
                            )}
                            {active >= 2 &&
                                getLinkComponent(
                                    active > 2,
                                    'deliveryStatusList',
                                    RoutesEnum.Details,
                                )}
                            {active >= 3 &&
                                getLinkComponent(
                                    active > 3,
                                    `${t('deliverySlipNumber')}: ${
                                        trackingIds[0] || ''
                                    }`,
                                    RoutesEnum.Summary,
                                )}
                        </MuiBreadcrumbs>
                    </Box>
                </Box>
            </ScrollBoxStyling>
        </BoxContainer>
    );
};

export default Breadcrumbs;
