import { Box } from '@mui/material';
import React from 'react';
import Breadcrumbs from './Breadcrumbs';
import HeaderMenu from './HeaderMenu';

const AppHeader = () => {
    return (
        <Box>
            <HeaderMenu />
            <Breadcrumbs />
        </Box>
    );
};

export default AppHeader;
