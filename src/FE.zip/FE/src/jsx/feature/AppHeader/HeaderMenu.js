import React, { useCallback, useMemo, useState } from 'react';
import { Box, Menu, MenuItem, Typography, useMediaQuery } from '@mui/material';
import ArrowDropDownIconMui from '@mui/icons-material/ArrowDropDown';
import moment from 'moment-timezone';
import { useTranslation } from 'react-i18next';
import styled, { useTheme } from 'styled-components';
import ClientContext from '../../container/ClientContext';
import Link from '../common/StyledComponent/Link';
import { i18n } from '../../../i18n';
import { Splitter } from '../AppBody/styles';

const BoxContainer = styled(Box)`
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #e7e9ee;
    padding: 0 ${(props) => props.theme.styleConfig.appContainerPadding.lg};
    height: calc(
        ${(props) => props.theme.styleConfig.headerMenuHeight.lg} - 1px
    );
    ${(props) => props.theme.breakpoints.down('lg')} {
        padding: 0 ${(props) => props.theme.styleConfig.appContainerPadding.md};
    }
    ${(props) => props.theme.breakpoints.down('sm')} {
        padding: 0 ${(props) => props.theme.styleConfig.appContainerPadding.sm};
        height: calc(
            ${(props) => props.theme.styleConfig.headerMenuHeight.sm} - 1px
        );
    }
`;

const ImageBox = styled(Box)`
    height: ${(props) => props.theme.styleConfig.logoHeight.sm};
    ${(props) => props.theme.breakpoints.down('sm')} {
        height: ${(props) => props.theme.styleConfig.logoHeight.xs};
    }
`;

const LanguageBox = styled(Typography)`
    color: #67718e !important;
    font-weight: 700 !important;
    cursor: pointer;
    display: flex;
    align-items: center;
`;

const ArrowDropDownIcon = styled(ArrowDropDownIconMui)`
    color: #67718e;
    height: 16px;
    width: 16px;
    margin-left: 2px;
    display: flex !important;
    align-items: center !important;
    cursor: pointer;
`;

const HeaderMenu = () => {
    const [anchorEl, setAnchorEl] = React.useState(null);
    const { clientTheme } = React.useContext(ClientContext);
    const theme = useTheme();
    const { t } = useTranslation();
    const isSmallScreen = useMediaQuery(theme.breakpoints.down('sm'));

    const defaultLng = useMemo(() => {
        return clientTheme.language.find(
            (item) => item.lngKey === i18n.language,
        );
    }, [clientTheme.language]);

    const [lng, setLng] = useState(defaultLng || clientTheme.language[0]);

    const handleClick = useCallback((event) => {
        setAnchorEl(event.currentTarget);
    }, []);

    const handleClose = useCallback(() => {
        setAnchorEl(null);
    }, []);

    const handleSelect = useCallback(
        (data) => () => {
            i18n.changeLanguage(data.lngKey);
            moment.locale(data.lngKey);
            setLng(data);
            handleClose();
        },
        [handleClose],
    );

    return (
        <BoxContainer>
            <ImageBox>
                <a href={clientTheme.brand.websiteUrl}>
                    <img
                        height="100%"
                        src={clientTheme.brand.logoUrl}
                        alt={clientTheme.brand.logoImgAlt}
                    />
                </a>
            </ImageBox>
            <Box display="flex" alignItems="center">
                <Typography variant="body2">
                    <Link>
                        {isSmallScreen ? t('getHelp') : t('getHelpSupport')}
                    </Link>
                </Typography>
                <Splitter />
                <Typography variant="body2">
                    <Link>{t('faq')}</Link>
                </Typography>
                {clientTheme?.language?.length > 1 && (
                    <React.Fragment>
                        <Splitter />
                        <LanguageBox variant="title4" onClick={handleClick}>
                            {isSmallScreen ? lng.shortName : lng.title}
                            <ArrowDropDownIcon onClick={handleClick} />
                        </LanguageBox>
                        <Menu
                            anchorEl={anchorEl}
                            open={Boolean(anchorEl)}
                            onClose={handleClose}
                            PaperProps={{
                                style: {
                                    width: '160px',
                                    borderRadius: '4px',
                                    backgroundColor: '#ffffff',
                                    boxShadow:
                                        '0px 0px 4px rgba(17, 19, 24, 0.16)',
                                },
                            }}
                            anchorOrigin={{
                                vertical: 'bottom',
                                horizontal: 'right',
                            }}
                            transformOrigin={{
                                horizontal: 'right',
                                vertical: 'top',
                            }}
                        >
                            <Box margin={'4px 16px 8px'}>
                                <Typography variant="title4">
                                    Language
                                </Typography>
                            </Box>
                            <Box overflow="auto" maxHeight="190px">
                                {clientTheme.language.map((item) => (
                                    <MenuItem
                                        key={item.key}
                                        onClick={handleSelect(item)}
                                    >
                                        <Box style={{ padding: '4px 0' }}>
                                            <Typography variant="caption1">
                                                {item.name}
                                            </Typography>
                                        </Box>
                                    </MenuItem>
                                ))}
                            </Box>
                        </Menu>
                    </React.Fragment>
                )}
            </Box>
        </BoxContainer>
    );
};

export default HeaderMenu;
