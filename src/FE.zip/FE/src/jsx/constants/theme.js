import { createTheme } from '@mui/material/styles';

const theme = createTheme({
    breakpoints: {
        values: {
            xs: 0,
            sm: 750,
            md: 850,
            lg: 1100,
            xl: 1400,
        },
    },
    palette: {
        primary: {
            main: '#0072f5',
        },
        success: {
            main: '#2CC92C',
        },
        error: {
            main: '#DC2518',
        },
        dark: {
            main: '#67718E',
        },
        link: '#0072f5',
    },
    typography: {
        fontFamily:
            'Noto Sans Display,Helvetica Neue,Arial,Helvetica,sans-serif',
        title1: {
            fontSize: '20px',
            fontWeight: 600,
            lineHeight: '28px',
            color: '#111318',
        },
        title2: {
            fontSize: '16px',
            fontWeight: 600,
            lineHeight: '24px',
            color: '#111318',
        },
        title3: {
            fontSize: '14px',
            fontWeight: 600,
            lineHeight: '20px',
            color: '#111318',
        },
        title4: {
            fontSize: '12px',
            fontWeight: 600,
            lineHeight: '16px',
            color: '#111318',
        },
        body1: {
            fontSize: '14px',
            fontWeight: 400,
            lineHeight: '20px',
            color: '#67718E',
        },
        body2: {
            fontSize: '12px',
            fontWeight: 400,
            lineHeight: '16px',
            color: '#67718E',
        },
        caption1: {
            fontSize: '14px',
            fontWeight: 400,
            lineHeight: '20px',
            color: '#111318',
        },
        caption2: {
            fontSize: '12px',
            fontWeight: 400,
            lineHeight: '16px',
            color: '#111318',
        },
        button: {
            fontSize: '14px',
            fontWeight: 700,
            lineHeight: '20px',
        },
        breadcrumbs: {
            fontSize: '12px',
            fontWeight: 400,
            lineHeight: '16px',
            color: '#111318',
        },
    },
    overrides: {
        MuiCssBaseline: {
            '@global': {
                '*::-webkit-scrollbar': {
                    width: '3px',
                    height: '1px',
                    borderRadius: '2rem',
                },
                '*::-webkit-scrollbar-thumb': {
                    background: '#888',
                },
            },
        },
    },
    styleConfig: {
        logoHeight: { xs: '24px', sm: '32px' },
        loadingLogoHeight: { xs: '40px', sm: '50px', lg: '60px' },
        appContainerPadding: { sm: '16px', md: '40px', lg: '160px' },
        headerMenuHeight: { sm: '56px', md: '64px', lg: '64px' },
        breadcrumbsHeight: { sm: '42px', md: '48px', lg: '48px' },
        footerHeight: { sm: '85px', md: '52px', lg: '52px' },
    },
});

export default theme;
