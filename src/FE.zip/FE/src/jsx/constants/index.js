export const STATUS_COLOR = {
    cancelled: '#fbdcda',
    completed: '#DEF8DE',
    executing: '#D6E9FF',
    assigned: '#add3ff',
    planned: '#FFF1D6',
    planning: '#ffe4ad',
    parked: '#fee7d7',
    open: '#F3F4F6',
    received: '#e7e9ee',
};

export const STATUS_CODE_ONLY_BORDER = [
    'open',
    'received',
    'planning',
    'assigned',
];

export const ALLOW_CANCEL_STATUS_LIST = [
    'OPEN',
    'RECEIVED',
    'PARKED',
    'PLANNING',
    'PLANNED',
    'ASSIGNED',
    'EXECUTING',
];

export const ORDER_PERFORMED_STATUS_LIST = ['COMPLETED', 'CANCELLED'];

export const ALLOW_ON_THE_WAY_STATUS_LIST = ['PLANNED'];

export const ALLOW_HOMEBASE_DETAILS_STATUS_LIST = ['PLANNED', 'EXECUTING'];
