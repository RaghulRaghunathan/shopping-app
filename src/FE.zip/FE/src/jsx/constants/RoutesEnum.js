export default {
    LandingPage: '/',
    Summary: '/summary',
    Details: '/details',
};
