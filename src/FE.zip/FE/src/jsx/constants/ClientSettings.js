const defaultSetting = {
    brand: {
        logoUrl: `${process.env.PUBLIC_URL}` + '/assets/images/logo-locus.svg',
        logoImgAlt: 'LOCUS',
        websiteUrl: 'https://locus.sh/',
        copyRights: 'Copyright © 2022 MARA Labs Inc.',
        favIcon:
            `${process.env.PUBLIC_URL}` + '/assets/images/favicon-locus.ico',
        title: 'trackingLocus',
        adsImgUrl: [
            `${process.env.PUBLIC_URL}` + '/assets/images/carousel-locus-1.png',
            `${process.env.PUBLIC_URL}` + '/assets/images/carousel-locus-2.png',
            `${process.env.PUBLIC_URL}` + '/assets/images/carousel-locus-3.png',
            `${process.env.PUBLIC_URL}` + '/assets/images/carousel-locus-4.png',
        ],
    },
    timeZone: 'Asia/Kolkata',
    showCarousel: 'true',
    language: [
        {
            key: 'english',
            name: 'English',
            shortName: 'EN',
            lngKey: 'en',
            title: 'ENGLISH',
        },
    ],
};

const fastRetailing = {
    ...defaultSetting,
    brand: {
        logoUrl: `${process.env.PUBLIC_URL}` + '/assets/images/logo-fr.svg',
        logoImgAlt: 'ユニクロ｜UNIQLO',
        websiteUrl: 'https://www.uniqlo.com/jp/ja/',
        copyRights: 'Copyright © UNIQLO Co., Ltd. All rights reserved.',
        favIcon: `${process.env.PUBLIC_URL}` + '/assets/images/favicon-fr.ico',
        title: 'trackingFr',
        adsImgUrl: [
            `${process.env.PUBLIC_URL}` + '/assets/images/carousel-fr-1.jpeg',
            `${process.env.PUBLIC_URL}` + '/assets/images/carousel-fr-2.jpeg',
            `${process.env.PUBLIC_URL}` + '/assets/images/carousel-fr-3.jpeg',
            `${process.env.PUBLIC_URL}` + '/assets/images/carousel-fr-4.jpeg',
        ],
    },
    showCarousel: 'true',
    timeZone: 'Asia/Tokyo',
    language: [
        {
            key: 'english',
            name: 'English',
            shortName: 'EN',
            lngKey: 'en',
            title: 'ENGLISH',
        },
        {
            key: 'japanese',
            name: '日本語',
            shortName: '日本語',
            lngKey: 'ja',
            title: '日本語',
        },
    ],
    palette: {
        primary: {
            main: '#000000',
            contrastText: '#fff',
        },
        success: {
            main: '#000000',
        },
        error: {
            main: '#EE0000',
        },
        dark: {
            main: '#67718E',
        },
        link: '#005DB5',
    },
};

const ups = {
    ...defaultSetting,
    brand: {
        logoUrl: `${process.env.PUBLIC_URL}` + '/assets/images/logo-ups.svg',
        logoImgAlt: 'UPS',
        websiteUrl: 'https://about.ups.com/ae/en/home.html',
        copyRights:
            'Copyright ©1994- 2022  United Parcel Service of America, Inc. All rights reserved.',
        favIcon: `${process.env.PUBLIC_URL}` + '/assets/images/favicon-ups.ico',
        title: 'trackingUPS',
    },
    showCarousel: 'false',
    timeZone: 'America/Chicago',
    language: [
        {
            key: 'english',
            name: 'English',
            shortName: 'EN',
            lngKey: 'en',
            title: 'ENGLISH',
        },
    ],
    palette: {
        primary: {
            main: '#ffc400',
        },
        success: {
            main: '#ffc400',
        },
        error: {
            main: '#EE0000',
        },
        dark: {
            main: '#330000',
        },
        link: '#0662bb',
    },
};

const truper = {
    ...defaultSetting,
    brand: {
        logoUrl:
            'https://www.truper.com/skin/frontend/glam/default/images/logo_header.png',
        logoImgAlt: 'Truper® - Es mucha herramienta',
        websiteUrl: 'https://www.truper.com',
        copyRights: '© 2021 TRUPER S.A. de C.V. Todos los derechos reservados.',
        favIcon: 'https://www.truper.com/media/favicon/default/favicon.png',
        title: 'trackingTruper',
        adsImgUrl: [
            `${process.env.PUBLIC_URL}` +
                '/assets/images/carousel-truper-1.png',
            `${process.env.PUBLIC_URL}` +
                '/assets/images/carousel-truper-2.jpg',
        ],
    },
    showCarousel: 'true',
    timeZone: 'America/Bahia_Banderas',
    language: [
        {
            key: 'english',
            name: 'English',
            shortName: 'EN',
            lngKey: 'en',
            title: 'ENGLISH',
        },
    ],
    palette: {
        primary: {
            main: '#ff6500',
            contrastText: '#fff',
        },
        success: {
            main: '#ff6500',
        },
        error: {
            main: '#df280a',
        },
        dark: {
            main: '#330000',
        },
        link: '#0662bb',
    },
    styleConfig: {
        loadingLogoHeight: { xs: '25px', sm: '30px', lg: '35px' },
        logoHeight: { xs: '20px', sm: '24px' },
    },
};

const goodfood = {
    ...defaultSetting,
    brand: {
        logoUrl:
            `${process.env.PUBLIC_URL}` + '/assets/images/logo-goodfood.jpeg',
        logoImgAlt: 'Goodfood',
        websiteUrl: 'https://www.makegoodfood.ca',
        landingMessage1:
            "Enter the order number to track the status of your shipment. You can find the order ID in the SMS confirming your order is on it's way",
        landingMessage2: ' ',
        copyRights: '',
        favIcon:
            `${process.env.PUBLIC_URL}` + '/assets/images/favicon-goodfood.ico',
        title: 'trackingGoodfood',
        adsImgUrl: [
            `${process.env.PUBLIC_URL}` +
                '/assets/images/carousel-goodfood-1.jpg',
            `${process.env.PUBLIC_URL}` +
                '/assets/images/carousel-goodfood-2.jpg',
            `${process.env.PUBLIC_URL}` +
                '/assets/images/carousel-goodfood-3.jpg',
            `${process.env.PUBLIC_URL}` +
                '/assets/images/carousel-goodfood-4.jpg',
        ],
    },
    showCarousel: 'true',
    timeZone: 'Asia/Kolkata',
    language: [
        {
            key: 'english',
            name: 'English',
            shortName: 'EN',
            lngKey: 'en',
            title: 'ENGLISH',
        },
    ],
    palette: {
        primary: {
            main: '#68c9cb',
            contrastText: '#fff',
        },
        success: {
            main: '#68c9cb',
        },
        error: {
            main: '#e6000f',
        },
        dark: {
            main: '#330000',
        },
        link: '#68c9cb',
    },
    styleConfig: {
        loadingLogoHeight: { xs: '50px', sm: '60px', lg: '70px' },
        logoHeight: { xs: '34px', sm: '42px' },
    },
};

export default {
    defaultSetting,
    locus: defaultSetting,
    'fr-uat': fastRetailing,
    'ups-demo': ups,
    truper,
    'goodfood-oiq-devo': goodfood,
    'goodfood-oiq': goodfood,
};
