import React, { useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import moment from 'moment-timezone';
import i18n from '../../i18n';
import AppContainer from '../feature/AppContainer/AppContainer';
import ClientContext from '../container/ClientContext';

const AppRoutes = () => {
    const { clientTheme } = React.useContext(ClientContext);
    const { t } = useTranslation();

    useEffect(() => {
        moment.tz.setDefault(clientTheme.timeZone);
    }, [clientTheme.timeZone]);

    useEffect(() => {
        if (document.getElementById('fav-icon'))
            document.getElementById('fav-icon').href =
                clientTheme.brand.favIcon;

        if (document.getElementById('shortcut-fav-icon'))
            document.getElementById('shortcut-fav-icon').href =
                clientTheme.brand.favIcon;
    }, [clientTheme.brand]);

    useEffect(() => {
        document.title = t(clientTheme.brand.title);
        moment.locale(i18n.language);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [i18n.language, t]);

    return (
        <Routes>
            <Route path="*" element={<AppContainer />} />
        </Routes>
    );
};

export default AppRoutes;
