import React from 'react';
import PageNotFound from '../feature/common/PageNotFound';

const RouteNotFound = () => <PageNotFound />;

export default RouteNotFound;
