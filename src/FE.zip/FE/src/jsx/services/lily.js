import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
const { CONFIG } = require('../config');

export const baseQuery = async (args, WebApi, extraOptions) => {
    const { clientId } = args;
    const baseUrl = CONFIG.LOCUS.LILY_BASE_URL;

    const rawBaseQuery = fetchBaseQuery({
        baseUrl: `${baseUrl}/v1/client/${clientId}`,
    });
    return rawBaseQuery(args, WebApi, extraOptions);
};

export const api = createApi({
    baseQuery,
    endpoints: (builder) => ({
        getOrderDetails: builder.mutation({
            query: ({ clientId, payload }) => {
                return {
                    url: `order/search`,
                    method: 'POST',
                    body: payload,
                    clientId,
                };
            },
        }),
        getOrder: builder.mutation({
            query: ({ clientId, orderId }) => {
                return {
                    url: `order/${orderId}`,
                    method: 'GET',
                    clientId,
                };
            },
        }),
        cancelOrder: builder.mutation({
            query: ({ clientId, orderId }) => {
                return {
                    url: `order/${orderId}/cancel`,
                    method: 'PUT',
                    clientId,
                };
            },
        }),
        updateOnTheWay: builder.mutation({
            query: ({ clientId, orderId }) => {
                return {
                    url: `order/${orderId}/execute`,
                    method: 'POST',
                    clientId,
                };
            },
        }),
    }),
});

export const {
    useGetOrderDetailsMutation,
    useGetOrderMutation,
    useCancelOrderMutation,
    useUpdateOnTheWayMutation,
} = api;
