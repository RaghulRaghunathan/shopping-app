import { useTranslation } from 'react-i18next';
import {
    ORDER_PERFORMED_STATUS_LIST,
    ALLOW_ON_THE_WAY_STATUS_LIST,
    ALLOW_HOMEBASE_DETAILS_STATUS_LIST,
} from '../constants';

export const isStorePickUpOrder = (orderType) => orderType === 'STORE_PICKUP';

export const showHomebaseDetails = (orderType, orderStatus) => {
    return (
        isStorePickUpOrder(orderType) &&
        ALLOW_HOMEBASE_DETAILS_STATUS_LIST.includes(orderStatus)
    );
};

export const allowOnTheWayUpdate = (orderType, orderStatus) => {
    return (
        isStorePickUpOrder(orderType) &&
        ALLOW_ON_THE_WAY_STATUS_LIST.includes(orderStatus)
    );
};

export const showDeliveryDateInfo = (orderStatus) => {
    return !ORDER_PERFORMED_STATUS_LIST.includes(orderStatus);
};

export const getCustomStatusAndDescriptionKey = (status, subStatus) => {
    switch (status) {
        case 'RECEIVED':
            return 'received';
        case 'OPEN':
            return 'open';
        case 'PARKED':
            return 'parked';
        case 'PLANNING':
            return 'planning';
        case 'PLANNED':
            return 'planned';
        case 'ASSIGNED':
            return 'assigned';
        case 'EXECUTING':
            switch (subStatus) {
                case 'Drop Enroute':
                    return 'dropEnroute';
                case 'Drop Reached':
                    return 'dropReached';
                default:
                    return 'executing';
            }
        case 'COMPLETED':
            return 'completed';
        case 'CANCELLED':
            return 'cancelled';
        default:
            return status;
    }
};

export const useGetServiceStatus = (type, status, subStatus) => {
    const { t } = useTranslation();
    const key = getCustomStatusAndDescriptionKey(status, subStatus);
    return t(`statusKey.${type}.${key}.status`);
};

export const useGetServiceDescription = (type, status, subStatus) => {
    const { t } = useTranslation();
    const key = getCustomStatusAndDescriptionKey(status, subStatus);
    return t(`statusKey.${type}.${key}.description`);
};
