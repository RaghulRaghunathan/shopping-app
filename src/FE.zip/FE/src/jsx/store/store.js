import { configureStore } from '@reduxjs/toolkit';
import { api as lilyApi } from '../services/lily';
import appReducer from '../container/appSlice';

export const store = configureStore({
    reducer: {
        [lilyApi.reducerPath]: lilyApi.reducer,
        app: appReducer,
    },
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware().concat(lilyApi.middleware),
});
