import React, { useMemo } from 'react';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import { ThemeProvider as MuiThemeProvider } from '@mui/material';
import { ThemeProvider } from 'styled-components';
import moment from 'moment-timezone';
import CircularLoader from '../feature/common/StyledComponent/CircularLoader';
import AppRoutes from '../routes/AppRoutes';
import { store } from '../store/store';
import mainTheme from '../constants/theme';
import ClientContext from './ClientContext';

import 'moment/min/locales';
moment.defaultFormat = 'YYYY-MM-DDTHH:mm:ss.SSSZ';

const App = () => {
    const { clientTheme } = React.useContext(ClientContext);

    const theme = useMemo(() => {
        const theme = mainTheme;
        theme.palette = {
            ...theme.palette,
            ...clientTheme?.palette,
        };
        theme.styleConfig = {
            ...theme.styleConfig,
            ...clientTheme?.styleConfig,
        };
        return theme;
    }, [clientTheme]);

    return (
        <Provider store={store}>
            <BrowserRouter>
                <MuiThemeProvider theme={theme}>
                    <ThemeProvider theme={theme}>
                        <React.Suspense fallback={<CircularLoader />}>
                            <AppRoutes />
                        </React.Suspense>
                    </ThemeProvider>
                </MuiThemeProvider>
            </BrowserRouter>
        </Provider>
    );
};

export default App;
