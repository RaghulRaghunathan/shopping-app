import { createSlice } from '@reduxjs/toolkit';

const slice = createSlice({
    name: 'app',
    initialState: {
        trackingIds: [],
        bodyComponent: null,
    },
    reducers: {
        setTrackingIds: (state, { payload }) => {
            state.trackingIds = payload;
        },
        setBodyComponent: (state, { payload }) => {
            state.bodyComponent = payload;
        },
    },
});

export const { setTrackingIds, setBodyComponent } = slice.actions;

export default slice.reducer;
