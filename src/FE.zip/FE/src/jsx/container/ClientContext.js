import React from 'react';
import { CONFIG } from '../config';
import ClientSettings from '../constants/ClientSettings';

let clientId = null;

if (CONFIG.MANUAL_CLIENT_ID === 'true')
    clientId = window.prompt('Enter Client Id');
else if (CONFIG.LOCUS.CLIENT_ID) clientId = CONFIG.LOCUS.CLIENT_ID;
else clientId = window.location.href.split('.')[0]?.split('https://')[1];

export default React.createContext({
    clientId,
    clientTheme:
        clientId && ClientSettings[clientId]
            ? ClientSettings[clientId]
            : ClientSettings.defaultSetting,
});
