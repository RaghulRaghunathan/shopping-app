module.exports = {
    bracketSpacing: true,
    printWidth: 80,
    useTabs: false,
    overrides: [
        {
            files: ['*.js'],
            options: {
                parser: 'babel-flow',
                arrowParens: 'always',
                singleQuote: true,
                semi: true,
                trailingComma: 'all',
                quoteProps: 'as-needed',
                jsxBracketSameLine: false,
                jsxSingleQuote: false,
                tabWidth: 4,
            },
        },
        {
            files: '*.json',
            options: {
                tabWidth: 2,
            },
        },
        {
            files: ['*.scss', '*.css'],
            options: {
                tabWidth: 2,
                singleQuote: true,
            },
        },
    ],
};
